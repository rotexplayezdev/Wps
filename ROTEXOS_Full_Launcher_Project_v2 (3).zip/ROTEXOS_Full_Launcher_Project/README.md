# ROTEXOS - Launcher, Theme Gallery and Developer Suite

Package `com.rotex.theme` | Kotlin | minSdk 23 | compile/target SDK 35 | Java 17
Made by Mahin - TikTok: Your_Mahin001

> **Build status: NOT built or tested.** The sandbox that produced this code had no Gradle/Android toolchain and no network,
> so nothing here has been compiled or run. Run the GitHub workflow and send the first error log if it fails.

## Sections
Home Dashboard | Apps | Theme Gallery (+details) | Developer Tools | Terminal | More: Theme Manager, Gradient Studio, Wallpapers, Update Center, Settings, About.

## Theme Gallery (independent of the app UI)
9 themes (Midnight Fluid, Liquid Glass, Ocean Glass, Tropical Frost, Aurora Glass, Crystal Dark, Minimal Monochrome, Sunset Neon, Rotex Neon),
search, categories, favorites, 5 preview pages each (home, widgets, app grid, custom page, lock-screen CONCEPT), palette and icon previews.
Selecting a theme never changes ROTEXOS. Preview = drawing, Export = wallpaper-only .mtz, real device action = wallpaper only.

## Developer tools
API Tester (OkHttp, true PATCH), JSON & YAML Studio, Regex Playground (timeout guard), Encoder & Hash, Color & Gradient Studio,
plus App Inspector, MTZ Inspector, code export, Device Profile, Intent Lab.

## Terminal
Sandboxed commands in the app's private folder (ls, cd, cat, mkdir, rm, cp, mv, grep, find, curl, sha256sum, ...). Unsupported Linux commands say so.

## GitHub workflows (all use the project ZIP upload method)
- `build-apk.yml`  : Run workflow -> debug APK artifact **ROTEXOS-APK**.
- `release-apk.yml`: signed release + GitHub Release + update.json + SHA-256 (for the in-app updater).
- `generate-keystore.yml`: one-time keystore generator (private repo only).
See `LIVE_UPDATE_GUIDE.md`.

## Limits
Lock screen, icon packs and system widgets cannot be replaced by a normal app. MTZ export is wallpaper-only and untested on Xiaomi Themes.
YAML support is a basic subset checker. Glass is simulated, not real-time blur. Cleartext http is allowed for the API Tester.
