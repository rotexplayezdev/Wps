# ROTEXOS live update - step by step

How it works: you run **Release ROTEXOS** in GitHub Actions. It builds a **signed** APK from the project ZIP and publishes a
GitHub Release containing `ROTEXOS-x.y.z.apk`, `ROTEXOS-x.y.z.apk.sha256` and `update.json`. The app reads the latest release,
downloads the APK, checks its SHA-256, and opens Android's package installer. You always tap "Install" yourself (Android never allows silent installs).

## Rules you must know
1. The repository must be **PUBLIC** for in-app updates (the app calls the GitHub API without a login). Never put secrets or the keystore in it.
2. Keep the signing key **forever**. If you lose it, nobody can update in place; they must uninstall first.
3. Install the **signed release APK** once (not the debug APK). The debug app is `com.rotex.theme.debug`, a different app.
4. Do not rename the release workflow (versionCode uses Unix time, so it always increases).

## Part A - one-time: make the signing key (needs a PRIVATE repo)
1. Create a temporary **private** repo, e.g. `rotex-keygen`. Upload only `.github/workflows/generate-keystore.yml` to it.
2. Actions > **Generate signing keystore** > Run workflow.
3. Open the finished run > Artifacts > download `ROTEXOS-KEYSTORE-PRIVATE` (expires in 1 day). Unzip it.
4. Save `rotex-release.jks` in a safe place (Google Drive / PC). This is your permanent key.
5. Open `secrets.txt`. It has four values.

## Part B - add the 4 secrets to your MAIN (public) repo
Main repo > Settings > Secrets and variables > Actions > New repository secret. Create exactly:
| Name | Value from secrets.txt |
|---|---|
| ROTEX_KEYSTORE_B64 | the long base64 line |
| ROTEX_KEYSTORE_PASSWORD | password |
| ROTEX_KEY_ALIAS | rotex |
| ROTEX_KEY_PASSWORD | password (same as above) |
Then delete the temporary private repo `rotex-keygen` and the downloaded `secrets.txt`.

## Part C - publish the first release
1. Main repo contains `ROTEXOS_Full_Launcher_Project_v2.zip` (root) and `.github/workflows/release-apk.yml`.
2. Actions > **Release ROTEXOS** > Run workflow > version `1.0.0`, add release notes > Run.
3. When green, open Releases: you should see `ROTEXOS v1.0.0` with 3 files.
4. Download `ROTEXOS-1.0.0.apk` on your phone and install it.

## Part D - ship an update
1. Upload a new project ZIP with the **same name** (replace the old one) and commit.
2. Run **Release ROTEXOS** again with a higher version, e.g. `1.1.0`, plus notes.
3. On the phone: ROTEXOS > More > Update Center > Check for updates > Download & install > confirm in Android's installer.

## Troubleshooting
- "Missing repository secrets": a secret name is misspelled or empty.
- "Signed app-release.apk was not produced": signing secrets were not applied; recheck all four.
- Update Center says repository not configured: tap Change repository and enter `owner/repo`.
- "SHA-256 mismatch" or "package name mismatch": the app refuses the file; this is the safety check working.
- Install blocked: allow "Install unknown apps" for ROTEXOS when Android asks.
