package com.rotex.theme

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.util.Random

internal class ThemeItem(val file: File, val info: MtzInfo?, val error: String?, val thumb: Bitmap?)

// =====================================================================
// HOME
// =====================================================================
// =====================================================================
// APPS
// =====================================================================
internal fun MainActivity.pinnedPackages(): List<String> =
    (prefs.getString("pins", "") ?: "").split(',').filter { it.isNotEmpty() }

internal fun MainActivity.togglePin(pkg: String) {
    val cur = pinnedPackages().toMutableList()
    if (cur.contains(pkg)) cur.remove(pkg) else cur.add(pkg)
    prefs.edit().putString("pins", cur.joinToString(",")).apply()
}

internal fun MainActivity.launchApp(pkg: String) {
    val i = packageManager.getLaunchIntentForPackage(pkg)
    if (i == null) {
        toast("Cannot open this app")
        return
    }
    try {
        startActivity(i)
    } catch (e: Exception) {
        toast("Cannot open: ${e.message}")
    }
}

internal fun MainActivity.appGrid(list: List<AppEntry>): View {
    val cols = prefs.getInt("cols", 4).coerceIn(3, 5)
    val pins = pinnedPackages()
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    for (rowItems in list.chunked(cols)) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until cols) {
            val e = rowItems.getOrNull(i)
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(8), dp(2), dp(8))
            if (e != null) {
                val iv = ImageView(this)
                iv.setImageDrawable(e.icon)
                cell.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)))
                val t = label((if (pins.contains(e.pkg)) "\u2605 " else "") + e.label, 11, Pal.ink)
                t.gravity = Gravity.CENTER
                t.maxLines = 1
                t.ellipsize = TextUtils.TruncateAt.END
                t.setPadding(0, dp(4), 0, 0)
                cell.addView(t)
                cell.setOnClickListener { launchApp(e.pkg) }
                cell.setOnLongClickListener {
                    appMenu(e)
                    true
                }
            }
            row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(row)
    }
    return col
}

internal fun MainActivity.appsPage() {
    val search = EditText(this)
    search.hint = "Search installed apps"
    search.setSingleLine(true)
    search.setTextColor(Pal.ink)
    search.setHintTextColor(Pal.sub)
    search.background = rounded(Pal.field, 14)
    search.setPadding(dp(14), dp(12), dp(14), dp(12))
    content.addView(search, lp(bottom = 12))
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    content.addView(box)
    content.addView(label("Tip: long-press an app to pin it, inspect it or share its APK.", 12, Pal.sub), lp(top = 8))
    loadApps { apps ->
        fun populate(q: String) {
            box.removeAllViews()
            val m = apps.filter { it.label.contains(q.trim(), true) }
            if (m.isEmpty()) box.addView(label("No matching apps.", 14, Pal.sub)) else box.addView(appGrid(m))
        }
        search.addTextChangedListener(watcher { populate(it) })
        populate("")
    }
}

internal fun MainActivity.appMenu(e: AppEntry) {
    val isPinned = pinnedPackages().contains(e.pkg)
    val items = arrayOf(if (isPinned) "Unpin from Home" else "Pin to Home", "Inspect (developer)", "App info", "Share APK (base)", "Uninstall")
    dialog().setTitle(e.label).setItems(items) { _, i ->
        when (i) {
            0 -> {
                togglePin(e.pkg)
                showPage(currentPage)
            }
            1 -> inspectApp(e.pkg)
            2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
            3 -> shareApk(e)
            else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}")))
        }
    }.show()
}

// DEV FEATURE 1: App Inspector
internal fun MainActivity.inspectApp(pkg: String) {
    runBg({ runCatching { DevTools.inspectApp(packageManager, pkg) } }) { r ->
        r.onSuccess { showText("App Inspector", it) }.onFailure { toast("Inspect failed: ${it.message}") }
    }
}

internal fun MainActivity.shareApk(e: AppEntry) {
    toast("Preparing APK...")
    runBg({
        runCatching {
            val src = File(packageManager.getApplicationInfo(e.pkg, 0).sourceDir)
            val dir = File(cacheDir, "shared")
            dir.mkdirs()
            val dst = File(dir, "${e.pkg}.apk")
            src.copyTo(dst, overwrite = true)
            dst
        }
    }) { r ->
        r.onSuccess { shareFile(it, "application/vnd.android.package-archive", "Share APK") }
            .onFailure { toast("Cannot share APK: ${it.message}") }
    }
}

// =====================================================================
// THEMES (MTZ library)
// =====================================================================
internal fun MainActivity.themesPage() {
    addCard(
        "Import MTZ theme",
        "Choose an .mtz from your phone. ROTEXOS checks that it is a real ZIP with a description.xml and rejects corrupted or unsafe files.",
        "Choose .mtz file"
    ) { pickFile(REQ_IMPORT_MTZ) }
    addCard(
        "Xiaomi compatibility",
        "MTZ is Xiaomi's theme format. ROTEXOS stores and builds themes, then hands them to the Xiaomi Themes app. Whether a theme can be applied depends on your MIUI/HyperOS version and Xiaomi's own checks; ROTEXOS never bypasses them."
    )
    content.addView(label("Theme library", 17, Pal.ink, true), lp(top = 4, bottom = 8))
    val listBox = LinearLayout(this)
    listBox.orientation = LinearLayout.VERTICAL
    content.addView(listBox)
    runBg({
        ThemeStore.list(this).map { f ->
            try {
                val info = Mtz.inspect(f)
                ThemeItem(f, info, null, info.previewBytes?.let { Mtz.decodeThumb(it, 240) })
            } catch (e: Exception) {
                ThemeItem(f, null, e.message ?: "Invalid theme", null)
            }
        }
    }) { items ->
        if (items.isEmpty()) listBox.addView(label("No themes yet. Import an .mtz or build one in Studio.", 13, Pal.sub))
        for (t in items) listBox.addView(themeCard(t), lp(bottom = 10))
    }
}

private fun MainActivity.themeCard(t: ThemeItem): View {
    val c = card()
    val top = LinearLayout(this)
    top.orientation = LinearLayout.HORIZONTAL
    if (t.thumb != null) {
        val iv = ImageView(this)
        iv.setImageBitmap(t.thumb)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.roundClip(dp(12).toFloat())
        top.addView(iv, LinearLayout.LayoutParams(dp(72), dp(128)))
    }
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(if (t.thumb != null) dp(14) else 0, 0, 0, 0)
    val info = t.info
    if (info != null) {
        col.addView(label(info.title, 16, Pal.ink, true))
        val meta = listOf(info.author, info.version.let { if (it.isEmpty()) "" else "v$it" }).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
        if (meta.isNotEmpty()) col.addView(label(meta, 12, Pal.sub))
        col.addView(label("${t.file.length() / 1024} KB  \u2022  ${info.entryNames.size} files", 12, Pal.sub))
    } else {
        col.addView(label(t.file.name, 15, Pal.ink, true))
        col.addView(label("Invalid: ${t.error}", 12, Pal.danger))
    }
    top.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
    c.addView(top)

    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    fun add(b: View) {
        row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
    }
    if (info != null) {
        add(btn("Apply", true) { applyInXiaomiThemes(t.file) })
        add(btn("Details", false) { showThemeDetails(t) })
        add(btn("Share", false) { shareFile(t.file, "application/octet-stream", "Share MTZ") })
    }
    add(btn("Delete", false) {
        dialog().setTitle("Delete theme?").setMessage(t.file.name)
            .setPositiveButton("Delete") { _, _ ->
                t.file.delete()
                showPage("Themes")
            }.setNegativeButton("Cancel", null).show()
    })
    c.addView(row, lp(top = 12))
    return c
}

internal fun describeMtz(info: MtzInfo, sizeBytes: Long, sha: String): String {
    val sb = StringBuilder()
    sb.append("Title: ").append(info.title).append('\n')
    if (info.author.isNotEmpty()) sb.append("Author: ").append(info.author).append('\n')
    if (info.version.isNotEmpty()) sb.append("Version: ").append(info.version).append('\n')
    sb.append("File size: ").append(sizeBytes / 1024).append(" KB\n")
    sb.append("Unpacked size: ").append(info.uncompressedBytes / 1024).append(" KB\n")
    sb.append("Entries: ").append(info.entryNames.size).append('\n')
    sb.append("SHA-256: ").append(sha).append('\n')
    sb.append("Editable in ROTEXOS Studio: ").append(if (info.studioJson != null) "yes" else "no").append("\n\nContents:\n")
    info.entryNames.take(80).forEach { sb.append("  ").append(it).append('\n') }
    if (info.entryNames.size > 80) sb.append("  ... and ${info.entryNames.size - 80} more\n")
    return sb.toString()
}

// DEV FEATURE 2: MTZ Inspector (library details)
internal fun MainActivity.showThemeDetails(t: ThemeItem) {
    val info = t.info ?: return
    runBg({ runCatching { Mtz.sha256(t.file) } }) { r ->
        val sha = r.getOrDefault("unavailable")
        val json = info.studioJson
        showText("Theme details", describeMtz(info, t.file.length(), sha), if (json != null) "Edit in Studio" else null) {
            try {
                studio.applyJson(json!!)
                showPage("Studio")
            } catch (e: Exception) {
                toast("Cannot open project: ${e.message}")
            }
        }
    }
}

internal fun MainActivity.inspectExternalMtz(uri: Uri) {
    runBg({
        runCatching {
            val tmp = File(cacheDir, "inspect.tmp")
            try {
                ThemeStore.copyLimited(this, uri, tmp)
                val info = Mtz.inspect(tmp)
                describeMtz(info, tmp.length(), Mtz.sha256(tmp))
            } finally {
                tmp.delete()
            }
        }
    }) { r ->
        r.onSuccess { showText("MTZ Inspector (not imported)", it) }
            .onFailure { showText("MTZ Inspector", "INVALID: ${it.message}") }
    }
}

internal fun MainActivity.importMtz(uri: Uri) {
    runBg({ runCatching { ThemeStore.importUri(this, uri) } }) { r ->
        r.onSuccess {
            toast("Imported: ${it.second.title}")
            showPage("Themes")
        }.onFailure { toast("Import failed: ${it.message ?: "unknown error"}") }
    }
}

internal fun MainActivity.applyInXiaomiThemes(f: File) {
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/octet-stream")
        i.setPackage("com.android.thememanager")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(i)
        return
    } catch (_: Exception) {
        // fall through to manual guidance
    }
    dialog().setTitle("Open in Xiaomi Themes")
        .setMessage(
            "The Xiaomi Themes app did not accept the file directly.\n\n" +
                "1. Save a copy of the .mtz to your phone.\n" +
                "2. Open it from your file manager with the Themes app (or use Themes > import, if your version has it).\n\n" +
                "Newer HyperOS versions may refuse unofficial themes. ROTEXOS does not bypass that."
        )
        .setPositiveButton("Save copy") { _, _ ->
            pendingExport = f
            createDoc(REQ_SAVE_EXPORT, f.name, "application/octet-stream")
        }
        .setNeutralButton("Open Themes app") { _, _ ->
            val l = packageManager.getLaunchIntentForPackage("com.android.thememanager")
            if (l != null) startActivity(l) else toast("Xiaomi Themes app not found on this device")
        }
        .setNegativeButton("Close", null).show()
}

internal fun MainActivity.copyFileToUri(f: File, uri: Uri) {
    runBg({
        runCatching {
            val out = contentResolver.openOutputStream(uri) ?: throw IOException("Cannot write to the chosen location")
            out.use { o -> f.inputStream().use { it.copyTo(o) } }
        }
    }) { r -> r.onSuccess { toast("Saved") }.onFailure { toast("Save failed: ${it.message}") } }
}

internal fun MainActivity.writeTextToUri(text: String, uri: Uri) {
    runBg({
        runCatching {
            val out = contentResolver.openOutputStream(uri) ?: throw IOException("Cannot write to the chosen location")
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        }
    }) { r -> r.onSuccess { toast("Saved") }.onFailure { toast("Save failed: ${it.message}") } }
}

// =====================================================================
// STUDIO (gradient theme builder + MTZ export)
// =====================================================================
private fun randomColor(rnd: Random): Int =
    Color.HSVToColor(floatArrayOf(rnd.nextFloat() * 360f, 0.5f + rnd.nextFloat() * 0.45f, 0.55f + rnd.nextFloat() * 0.45f))

internal fun MainActivity.studioPage() {
    val st = studio
    val dm = realMetrics()
    val rnd = Random()

    val pv = GradientView(this)
    pv.radiusPx = dp(24).toFloat()
    val pw = 160
    val ph = (pw.toFloat() * dm.heightPixels.coerceAtLeast(1) / dm.widthPixels.coerceAtLeast(1)).toInt().coerceIn(200, 420)
    val pvWrap = LinearLayout(this)
    pvWrap.gravity = Gravity.CENTER
    pvWrap.addView(pv, LinearLayout.LayoutParams(dp(pw), dp(ph)))
    content.addView(pvWrap, lp(bottom = 14))
    pv.spec = st.spec()

    val editor = LinearLayout(this)
    editor.orientation = LinearLayout.VERTICAL

    fun field(hint: String, value: String, onChange: (String) -> Unit): EditText {
        val et = EditText(this)
        et.hint = hint
        et.setText(value)
        et.setSingleLine(true)
        et.setTextColor(Pal.ink)
        et.setHintTextColor(Pal.sub)
        et.background = rounded(Pal.field, 12)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.addTextChangedListener(watcher(onChange))
        return et
    }

    val nameEt = field("Theme name", st.name) { st.name = it; pv.spec = st.spec() }

    fun render() {
        pv.spec = st.spec()
        editor.removeAllViews()
        val types = LinearLayout(this)
        types.orientation = LinearLayout.HORIZONTAL
        for (t in GType.values()) {
            val title = t.name.lowercase().replaceFirstChar { it.uppercase() }
            types.addView(
                btn(title, st.type == t) { st.type = t; render() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
            )
        }
        editor.addView(types, lp(bottom = 10))

        if (st.type == GType.LINEAR) {
            val angleLabel = label("Angle: ${st.angle}\u00B0", 13, Pal.sub)
            editor.addView(angleLabel)
            val sb = SeekBar(this)
            sb.max = 360
            sb.progress = st.angle
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    st.angle = p
                    angleLabel.text = "Angle: $p\u00B0"
                    pv.spec = st.spec()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            editor.addView(sb, lp(bottom = 8))
        }

        st.colors.forEachIndexed { i, c ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val chip = View(this)
            chip.background = rounded(c, 10)
            row.addView(chip, LinearLayout.LayoutParams(dp(40), dp(40)))
            val et = EditText(this)
            et.setText(hex(c))
            et.setSingleLine(true)
            et.setTextColor(Pal.ink)
            et.background = rounded(Pal.field, 12)
            et.setPadding(dp(12), dp(10), dp(12), dp(10))
            et.addTextChangedListener(watcher { s ->
                val col = parseHex(s)
                if (col != null && i < st.colors.size) {
                    st.colors[i] = col
                    chip.background = rounded(col, 10)
                    pv.spec = st.spec()
                }
            })
            row.addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(10), 0, dp(10), 0) })
            row.addView(btn("\u2715", false) {
                if (st.colors.size > 2) {
                    st.colors.removeAt(i)
                    render()
                } else {
                    toast("A gradient needs at least 2 colors")
                }
            }, LinearLayout.LayoutParams(dp(48), dp(42)))
            editor.addView(row, lp(bottom = 8))
        }

        val acts = LinearLayout(this)
        acts.orientation = LinearLayout.HORIZONTAL
        acts.addView(btn("+ Color", false) {
            if (st.colors.size < 5) {
                st.colors.add(randomColor(rnd))
                render()
            } else {
                toast("Maximum 5 colors")
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        acts.addView(btn("Randomize", false) {
            st.colors = MutableList(st.colors.size) { randomColor(rnd) }
            st.angle = rnd.nextInt(360)
            render()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        editor.addView(acts, lp(top = 4))
    }

    val c1 = card()
    c1.addView(label("Gradient", 17, Pal.ink, true))
    c1.addView(editor, lp(top = 10))
    content.addView(c1, lp(bottom = 12))
    render()

    val c2 = card()
    c2.addView(label("Presets (${Gradients.all().size})", 17, Pal.ink, true))
    c2.addView(gradientGrid(Gradients.all(), 3, 64) { s ->
        st.load(s)
        nameEt.setText(s.name)
        render()
    }, lp(top = 8))
    content.addView(c2, lp(bottom = 12))

    val c3 = card()
    c3.addView(label("Theme details", 17, Pal.ink, true))
    c3.addView(nameEt, lp(top = 8, bottom = 8))
    c3.addView(field("Author", st.author) { st.author = it }, lp(bottom = 8))
    c3.addView(btn("Wallpaper size: ${StudioState.RES_LABELS[st.resChoice]}", false) {
        dialog().setTitle("Wallpaper size").setItems(StudioState.RES_LABELS) { _, i ->
            st.resChoice = i
            showPage("Studio")
        }.show()
    })
    content.addView(c3, lp(bottom = 12))

    val c4 = card()
    c4.addView(label("Export", 17, Pal.ink, true))
    c4.addView(label("Builds a wallpaper theme (.mtz) with home + lock wallpapers, previews and an editable ROTEXOS project inside.", 12, Pal.sub), lp(top = 4, bottom = 10))
    c4.addView(btn("Build & export .mtz") { exportMtz() }, lp(bottom = 8))
    c4.addView(btn("Set as wallpaper now", false) {
        val spec = st.spec()
        val (w, h) = st.size(dm)
        chooseWallpaperTarget { which -> applyWallpaper({ spec.toBitmap(w, h) }, which) }
    }, lp(bottom = 8))
    c4.addView(btn("Copy gradient code (XML / Compose / CSS)", false) { showCodeExport() }, lp(bottom = 8))
    c4.addView(btn("Save project (.json)", false) {
        pendingText = st.spec().toJson(st.author).toString(2)
        createDoc(REQ_SAVE_JSON, "${st.spec().name.replace(Regex("[^A-Za-z0-9._-]+"), "_")}.rotexos.json", "application/json")
    }, lp(bottom = 8))
    c4.addView(btn("Open project (.json or ROTEXOS .mtz)", false) { pickFile(REQ_STUDIO_IMPORT) })
    content.addView(c4, lp(bottom = 12))
}

internal fun MainActivity.exportMtz() {
    val st = studio
    val spec = st.spec()
    val (w, h) = st.size(realMetrics())
    val author = st.author.trim()
    prefs.edit().putString("author", author).apply()
    toast("Building theme...")
    runBg({
        runCatching {
            val dest = ThemeStore.newFile(this, spec.name)
            Mtz.build(spec, spec.name, author, w, h, dest)
            dest
        }
    }) { r ->
        r.onSuccess { showExportDone(it) }.onFailure { toast("Export failed: ${it.message ?: "unknown error"}") }
    }
}

internal fun MainActivity.showExportDone(f: File) {
    val items = arrayOf("Save to phone storage...", "Share...", "Open in Xiaomi Themes", "Done (kept in Theme library)")
    dialog().setTitle("Theme exported").setMessage("${f.name} (${f.length() / 1024} KB)").setItems(items) { _, i ->
        when (i) {
            0 -> {
                pendingExport = f
                createDoc(REQ_SAVE_EXPORT, f.name, "application/octet-stream")
            }
            1 -> shareFile(f, "application/octet-stream", "Share MTZ")
            2 -> applyInXiaomiThemes(f)
            else -> {}
        }
    }.show()
}

internal fun MainActivity.importStudioProject(uri: Uri) {
    runBg({
        runCatching {
            val tmp = File(cacheDir, "studio_import.tmp")
            try {
                ThemeStore.copyLimited(this, uri, tmp)
                val isZip = tmp.inputStream().use {
                    val b = ByteArray(2)
                    it.read(b) == 2 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()
                }
                if (isZip) {
                    val j = Mtz.inspect(tmp).studioJson
                    if (j == null) throw IllegalArgumentException("This MTZ has no editable ROTEXOS project inside")
                    j
                } else {
                    if (tmp.length() > 256 * 1024) throw IllegalArgumentException("Not a ROTEXOS project file")
                    tmp.readText()
                }
            } finally {
                tmp.delete()
            }
        }
    }) { r ->
        r.onSuccess { json ->
            try {
                studio.applyJson(json)
                showPage("Studio")
                toast("Project loaded")
            } catch (e: Exception) {
                toast("Invalid project: ${e.message}")
            }
        }.onFailure { toast("Cannot open: ${it.message}") }
    }
}

// DEV FEATURE 3: gradient code export
internal fun MainActivity.showCodeExport() {
    val m = DevTools.codeExports(studio.spec(), studio.author)
    val keys = m.keys.toTypedArray()
    dialog().setTitle("Gradient code").setItems(keys) { _, i -> showText(keys[i], m[keys[i]].orEmpty()) }.show()
}

// =====================================================================
// WALLPAPERS
// =====================================================================
internal fun MainActivity.wallpapersPage() {
    addCard("Your own image", "Pick a photo and apply it to the home and/or lock screen.", "Choose image") {
        pickFile(REQ_WALLPAPER_IMAGE, "image/*")
    }
    val c = card()
    c.addView(label("Gradient wallpapers", 17, Pal.ink, true))
    val dm = realMetrics()
    c.addView(gradientGrid(Gradients.all(), 3, 96) { s ->
        val w = minOf(dm.widthPixels, dm.heightPixels)
        val h = maxOf(dm.widthPixels, dm.heightPixels)
        chooseWallpaperTarget { which -> applyWallpaper({ s.toBitmap(w, h) }, which) }
    }, lp(top = 8))
    content.addView(c, lp(bottom = 12))
}

// =====================================================================
// TOOLS (developer features)
// =====================================================================
// DEV FEATURE 5
internal fun MainActivity.showIntentLab() {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(8), dp(20), 0)
    val et = EditText(this)
    et.hint = "https://..., tel:..., geo:..., or a package name"
    et.setSingleLine(true)
    et.setTextColor(Pal.ink)
    et.setHintTextColor(Pal.sub)
    box.addView(et, lp(bottom = 8))
    fun go(i: Intent, fail: String) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast(fail)
        }
    }
    box.addView(btn("Open as URI (ACTION_VIEW)", true) {
        val s = et.text.toString().trim()
        if (s.isEmpty()) toast("Enter a URI first") else go(Intent(Intent.ACTION_VIEW, Uri.parse(s)), "No app can handle this URI")
    }, lp(bottom = 6))
    box.addView(btn("Launch package", false) {
        val l = packageManager.getLaunchIntentForPackage(et.text.toString().trim())
        if (l == null) toast("Package not found or has no launcher activity") else go(l, "Cannot launch")
    }, lp(bottom = 6))
    box.addView(btn("Developer options", false) {
        go(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS), "Enable Developer options first (tap build number 7 times)")
    }, lp(bottom = 6))
    box.addView(btn("Default apps settings", false) {
        go(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS), "Not available on this device")
    }, lp(bottom = 6))
    box.addView(btn("Xiaomi Themes app", false) {
        val l = packageManager.getLaunchIntentForPackage("com.android.thememanager")
        if (l == null) toast("Xiaomi Themes app not found") else go(l, "Cannot launch")
    }, lp(bottom = 6))
    val sv = android.widget.ScrollView(this)
    sv.addView(box)
    dialog().setTitle("Intent Lab").setView(sv).setPositiveButton("Close", null).show()
}

// =====================================================================
// SETTINGS / ABOUT
// =====================================================================
