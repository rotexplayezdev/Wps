package com.rotex.theme

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.DisplayMetrics
import java.io.File
import java.security.MessageDigest
import java.text.DateFormat
import java.util.Date
import java.util.Locale

object DevTools {

    private fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString(":") { "%02X".format(it) }

    /** Feature 1: App Inspector. */
    @Suppress("DEPRECATION")
    fun inspectApp(pm: PackageManager, pkg: String): String {
        val flags = if (Build.VERSION.SDK_INT >= 28) {
            PackageManager.GET_SIGNING_CERTIFICATES or PackageManager.GET_PERMISSIONS
        } else {
            PackageManager.GET_SIGNATURES or PackageManager.GET_PERMISSIONS
        }
        val pi = pm.getPackageInfo(pkg, flags)
        val ai = pi.applicationInfo ?: throw IllegalStateException("No application info")
        val sb = StringBuilder()
        fun line(k: String, v: String) {
            sb.append(k).append(": ").append(v).append('\n')
        }
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        val df = DateFormat.getDateTimeInstance()
        line("Name", pm.getApplicationLabel(ai).toString())
        line("Package", pkg)
        line("Version", "${pi.versionName ?: "?"} ($code)")
        if (Build.VERSION.SDK_INT >= 24) line("Min SDK", ai.minSdkVersion.toString())
        line("Target SDK", ai.targetSdkVersion.toString())
        line("Installed", df.format(Date(pi.firstInstallTime)))
        line("Updated", df.format(Date(pi.lastUpdateTime)))
        line("Debuggable", ((ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0).toString())
        line("System app", ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0).toString())
        val installer = try {
            pm.getInstallerPackageName(pkg)
        } catch (_: Exception) {
            null
        }
        line("Installer", installer ?: "unknown")
        line("APK path", ai.sourceDir)
        line("APK size", "${File(ai.sourceDir).length() / 1024} KB")
        if (ai.splitSourceDirs != null) line("Split APKs", ai.splitSourceDirs!!.size.toString())
        val sigs: Array<android.content.pm.Signature>? =
            if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
        sigs?.forEachIndexed { i, s -> line("Signer ${i + 1} SHA-256", sha256(s.toByteArray())) }
        val perms = pi.requestedPermissions
        line("Permissions", (perms?.size ?: 0).toString())
        perms?.sorted()?.forEach { sb.append("  • ").append(it).append('\n') }
        return sb.toString()
    }

    private fun sysProp(key: String): String = try {
        val c = Class.forName("android.os.SystemProperties")
        val m = c.getMethod("get", String::class.java, String::class.java)
        (m.invoke(null, key, "") as? String).orEmpty()
    } catch (_: Throwable) {
        ""
    }

    /** Feature 4: Device Profile (helps pick correct wallpaper / theme resolution). */
    fun deviceProfile(dm: DisplayMetrics, refreshRate: Float): String {
        val w = minOf(dm.widthPixels, dm.heightPixels)
        val h = maxOf(dm.widthPixels, dm.heightPixels)
        val miui = sysProp("ro.miui.ui.version.name")
        val hyper = sysProp("ro.mi.os.version.name")
        val sb = StringBuilder()
        fun line(k: String, v: String) {
            sb.append(k).append(": ").append(v).append('\n')
        }
        line("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
        line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        line("Security patch", Build.VERSION.SECURITY_PATCH ?: "unknown")
        line("MIUI", miui.ifEmpty { "not detected" })
        line("HyperOS", hyper.ifEmpty { "not detected" })
        line("Screen", "$w x $h px")
        line("Density", "${dm.densityDpi} dpi (x${String.format(Locale.US, "%.2f", dm.density)})")
        line("Refresh rate", String.format(Locale.US, "%.0f Hz", refreshRate))
        line("ABIs", Build.SUPPORTED_ABIS.joinToString(", "))
        line("Recommended wallpaper", "$w x $h px (portrait)")
        return sb.toString()
    }

    private fun slug(s: String) = s.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_').ifEmpty { "theme" }

    /** Feature 3: gradient code export. Returns label -> code. */
    fun codeExports(spec: GradientSpec, author: String): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        val cols = spec.colors
        val androidAngle = (((360 - spec.angle) % 360 + 22) / 45 * 45) % 360
        val typeAttr = when (spec.type) {
            GType.LINEAR -> "linear"
            GType.RADIAL -> "radial"
            GType.SWEEP -> "sweep"
        }
        val g = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        g.append("<shape xmlns:android=\"http://schemas.android.com/apk/res/android\" android:shape=\"rectangle\">\n")
        g.append("    <gradient\n        android:type=\"$typeAttr\"\n")
        if (spec.type == GType.LINEAR) g.append("        android:angle=\"$androidAngle\"\n")
        if (spec.type == GType.RADIAL) g.append("        android:gradientRadius=\"75%p\"\n")
        g.append("        android:startColor=\"${hex(cols.first())}\"\n")
        if (cols.size > 2) g.append("        android:centerColor=\"${hex(cols[cols.size / 2])}\"\n")
        g.append("        android:endColor=\"${hex(cols.last())}\" />\n</shape>\n")
        if (cols.size > 3) g.append("<!-- Android XML gradients support 3 colors max; use Compose/CSS for all ${cols.size}. -->\n")
        out["Android XML shape"] = g.toString()

        val composeColors = cols.joinToString(", ") { "Color(0xFF${hex(it).substring(1)})" }
        val brush = when (spec.type) {
            GType.LINEAR -> "Brush.linearGradient(colors = listOf($composeColors))"
            GType.RADIAL -> "Brush.radialGradient(colors = listOf($composeColors))"
            GType.SWEEP -> "Brush.sweepGradient(colors = listOf($composeColors))"
        }
        out["Jetpack Compose Brush"] = "val ${slug(spec.name)}Brush = $brush\n// Note: Compose linearGradient defaults to top-left to bottom-right; set start/end Offsets for ${spec.angle} degrees."

        val css = when (spec.type) {
            GType.LINEAR -> "linear-gradient(${(spec.angle + 90) % 360}deg, ${cols.joinToString(", ") { hex(it) }})"
            GType.RADIAL -> "radial-gradient(circle, ${cols.joinToString(", ") { hex(it) }})"
            GType.SWEEP -> "conic-gradient(from 0deg, ${cols.joinToString(", ") { hex(it) }}, ${hex(cols.first())})"
        }
        out["CSS"] = "background: $css;"

        val xml = StringBuilder("<resources>\n")
        cols.forEachIndexed { i, c -> xml.append("    <color name=\"${slug(spec.name)}_${i + 1}\">${hex(c)}</color>\n") }
        xml.append("</resources>\n")
        out["colors.xml"] = xml.toString()

        out["ROTEXOS project JSON"] = spec.toJson(author).toString(2)
        return out
    }
}
