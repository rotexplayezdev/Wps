package com.rotex.theme

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class MtzInfo(
    val title: String,
    val author: String,
    val version: String,
    val entryNames: List<String>,
    val uncompressedBytes: Long,
    val previewBytes: ByteArray?,
    val studioJson: String?
)

object Mtz {
    private const val MAX_ENTRIES = 5000
    private const val MAX_TOTAL = 600L * 1024 * 1024
    private const val MAX_SMALL_ENTRY = 8L * 1024 * 1024
    const val STUDIO_ENTRY = "rotexos/theme.json"

    /** Validates ZIP structure and reads metadata. Throws IllegalArgumentException with a readable message. */
    fun inspect(file: File): MtzInfo {
        val zip = try {
            ZipFile(file)
        } catch (e: Exception) {
            throw IllegalArgumentException("Not a valid ZIP archive (corrupted or wrong file)")
        }
        return zip.use {
            val names = ArrayList<String>()
            var total = 0L
            var desc: ZipEntry? = null
            var preview: ZipEntry? = null
            var studio: ZipEntry? = null
            val en = zip.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (names.size >= MAX_ENTRIES) throw IllegalArgumentException("Archive has too many entries")
                val n = e.name
                if (n.startsWith("/") || n.contains("\\") || n.split('/').any { seg -> seg == ".." }) {
                    throw IllegalArgumentException("Unsafe path inside archive: $n")
                }
                names.add(n)
                if (e.size > 0) total += e.size
                val low = n.lowercase()
                if (low == "description.xml") desc = e
                if (low == STUDIO_ENTRY) studio = e
                if (preview == null && low.startsWith("preview/") &&
                    (low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".png"))
                ) preview = e
            }
            if (names.isEmpty()) throw IllegalArgumentException("Archive is empty")
            if (total > MAX_TOTAL) throw IllegalArgumentException("Archive is too large when unpacked")
            if (desc == null) throw IllegalArgumentException("description.xml is missing - this is not a valid MTZ theme")

            var title = file.nameWithoutExtension
            var author = ""
            var version = ""
            try {
                val bytes = readSmall(zip, desc!!, 256 * 1024)
                val parser = android.util.Xml.newPullParser()
                parser.setInput(bytes.inputStream(), null)
                var tag = ""
                var ev = parser.eventType
                while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        org.xmlpull.v1.XmlPullParser.START_TAG -> tag = parser.name
                        org.xmlpull.v1.XmlPullParser.TEXT -> {
                            val t = parser.text.trim()
                            if (t.isNotEmpty()) when (tag.lowercase()) {
                                "title" -> title = t
                                "author", "designer" -> if (author.isEmpty()) author = t
                                "version" -> version = t
                            }
                        }
                        org.xmlpull.v1.XmlPullParser.END_TAG -> tag = ""
                    }
                    ev = parser.next()
                }
            } catch (_: Exception) {
                // keep file-name fallback; archive structure itself is valid
            }
            val previewBytes = try {
                preview?.let { if (it.size in 1..MAX_SMALL_ENTRY) readSmall(zip, it, MAX_SMALL_ENTRY.toInt()) else null }
            } catch (_: Exception) {
                null
            }
            val studioJson = try {
                studio?.let { String(readSmall(zip, it, 64 * 1024), Charsets.UTF_8) }
            } catch (_: Exception) {
                null
            }
            MtzInfo(title, author, version, names, total, previewBytes, studioJson)
        }
    }

    private fun readSmall(zip: ZipFile, e: ZipEntry, max: Int): ByteArray {
        return zip.getInputStream(e).use { ins ->
            val bos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var t = 0
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                t += n
                if (t > max) throw IOException("Entry too large")
                bos.write(buf, 0, n)
            }
            bos.toByteArray()
        }
    }

    /** Builds a wallpaper-only MTZ from a gradient (editable again in Studio). */
    fun build(spec: GradientSpec, name: String, author: String, w: Int, h: Int, dest: File) {
        val width = w.coerceIn(320, 4096)
        val height = h.coerceIn(320, 4096)
        if (width.toLong() * height > 12_000_000L) throw IllegalArgumentException("Resolution too large")
        val wall = spec.toBitmap(width, height)
        try {
            writePackage(wall, name, author, STUDIO_ENTRY, spec.copy(name = name).toJson(author).toString(2), dest)
        } finally {
            wall.recycle()
        }
    }

    /** Builds a wallpaper-only MTZ theme pack from any bitmap (used by the Theme Gallery). Does not recycle [wall]. */
    fun buildFromBitmap(wall: Bitmap, name: String, author: String, packJson: String, dest: File) {
        writePackage(wall, name, author, "rotexos/theme-pack.json", packJson, dest)
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun writePackage(wall: Bitmap, name: String, author: String, extraEntry: String, extraJson: String, dest: File) {
        val tw = 360
        val th = (tw.toFloat() * wall.height / wall.width).toInt().coerceAtLeast(120)
        val thumb = Bitmap.createScaledBitmap(wall, tw, th, true)
        val tmp = File(dest.parentFile, dest.name + ".part")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { z ->
                val xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<MIUI-Theme>\n" +
                    "  <title>${esc(name)}</title>\n  <author>${esc(author)}</author>\n" +
                    "  <designer>${esc(author)}</designer>\n  <version>1.0</version>\n</MIUI-Theme>\n"
                put(z, "description.xml", xml.toByteArray(Charsets.UTF_8))
                put(z, "wallpaper/default_wallpaper.jpg", jpeg(wall, 95))
                put(z, "wallpaper/default_lock_wallpaper.jpg", jpeg(wall, 95))
                put(z, "preview/preview_launcher_0.jpg", jpeg(thumb, 90))
                put(z, "preview/preview_lockscreen_0.jpg", jpeg(thumb, 90))
                put(z, extraEntry, extraJson.toByteArray(Charsets.UTF_8))
            }
            if (!tmp.renameTo(dest)) throw IOException("Could not save theme file")
        } finally {
            if (tmp.exists()) tmp.delete()
            thumb.recycle()
        }
    }

    private fun put(z: ZipOutputStream, name: String, data: ByteArray) {
        z.putNextEntry(ZipEntry(name))
        z.write(data)
        z.closeEntry()
    }

    private fun jpeg(b: Bitmap, q: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, bos)
        return bos.toByteArray()
    }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun decodeThumb(bytes: ByteArray, maxDim: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= maxDim && o.outHeight / (s * 2) >= maxDim) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}

object ThemeStore {
    private const val MAX_IMPORT = 300L * 1024 * 1024

    fun dir(ctx: Context): File = File(ctx.filesDir, "themes").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles()?.filter { it.isFile && it.extension.equals("mtz", true) }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun sanitize(s: String): String =
        s.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_', '.').take(40).ifEmpty { "theme" }

    fun newFile(ctx: Context, name: String): File {
        val base = sanitize(name)
        var f = File(dir(ctx), "$base.mtz")
        var i = 1
        while (f.exists()) f = File(dir(ctx), "$base-${i++}.mtz")
        return f
    }

    fun displayName(ctx: Context, uri: Uri): String? {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i)
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment
    }

    fun copyLimited(ctx: Context, uri: Uri, dest: File) {
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot read the selected file")
        ins.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_IMPORT) throw IllegalArgumentException("File is larger than 300 MB")
                    out.write(buf, 0, n)
                }
            }
        }
    }

    /** Copies, validates and stores a user-selected .mtz. Invalid files are never kept. */
    fun importUri(ctx: Context, uri: Uri): Pair<File, MtzInfo> {
        val display = displayName(ctx, uri) ?: "imported.mtz"
        if (!display.endsWith(".mtz", ignoreCase = true)) throw IllegalArgumentException("Please choose an .mtz file (got: $display)")
        val dest = newFile(ctx, display.substring(0, display.length - 4))
        val part = File(dest.parentFile, dest.name + ".part")
        try {
            copyLimited(ctx, uri, part)
            val info = Mtz.inspect(part)
            if (!part.renameTo(dest)) throw IOException("Could not store theme")
            return dest to info
        } finally {
            if (part.exists()) part.delete()
        }
    }
}
