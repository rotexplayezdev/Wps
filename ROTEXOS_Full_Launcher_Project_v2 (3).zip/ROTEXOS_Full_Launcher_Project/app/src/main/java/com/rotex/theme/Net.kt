package com.rotex.theme

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

object Net {
    private fun open(url: String): HttpURLConnection {
        if (!url.startsWith("https://")) throw IOException("Only HTTPS downloads are allowed")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "ROTEXOS-Android")
        c.setRequestProperty("Accept", "application/vnd.github+json, application/json, */*")
        return c
    }

    fun getText(url: String, maxBytes: Int = 512 * 1024): String {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val bos = ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > maxBytes) throw IOException("Response too large")
                    bos.write(buf, 0, n)
                }
            }
            return bos.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    fun download(url: String, dest: File, cancelled: AtomicBoolean, onProgress: (Long, Long) -> Unit) {
        dest.parentFile?.mkdirs()
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLength.toLong()
            c.inputStream.use { ins ->
                FileOutputStream(dest).use { out ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    var last = 0L
                    while (true) {
                        if (cancelled.get()) throw IOException("Cancelled")
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 150) {
                            last = now
                            onProgress(done, total)
                        }
                    }
                    onProgress(done, total)
                }
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        } finally {
            c.disconnect()
        }
    }
}

data class ReleaseInfo(
    val tag: String,
    val versionName: String,
    val title: String,
    val notes: String,
    val apkUrl: String?,
    val apkSize: Long,
    val pageUrl: String,
    val publishedAt: String,
    val sha256: String?,
    val versionCode: Long?
)

object Http {
    val client: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }
}

object Updater {
    const val PLACEHOLDER_OWNER = "YOUR_GITHUB_USERNAME"

    fun isConfigured(owner: String): Boolean = owner != PLACEHOLDER_OWNER && owner.isNotBlank()

    private fun validPart(s: String) = Regex("[A-Za-z0-9._-]{1,100}").matches(s)

    private fun cleanSha(s: String?): String? {
        val t = s?.trim()?.lowercase() ?: return null
        return if (Regex("[0-9a-f]{64}").matches(t)) t else null
    }

    /** Blocking. Reads the latest published GitHub release plus its update.json / .sha256 asset. */
    fun fetchLatest(owner: String, repo: String): ReleaseInfo {
        if (!validPart(owner) || !validPart(repo)) throw IOException("Invalid repository name")
        val o = JSONObject(Net.getText("https://api.github.com/repos/$owner/$repo/releases/latest"))
        val assets = o.optJSONArray("assets")
        var apkUrl: String? = null
        var apkSize = 0L
        var metaUrl: String? = null
        var shaUrl: String? = null
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                val n = a.optString("name")
                val u = a.optString("browser_download_url")
                if (apkUrl == null && n.endsWith(".apk", true)) {
                    apkUrl = u
                    apkSize = a.optLong("size")
                } else if (n.equals("update.json", true)) {
                    metaUrl = u
                } else if (n.endsWith(".sha256", true)) {
                    shaUrl = u
                }
            }
        }
        val tag = o.optString("tag_name")
        var vName = tag.removePrefix("v").removePrefix("V")
        var vCode: Long? = null
        var sha: String? = null
        if (metaUrl != null) {
            try {
                val m = JSONObject(Net.getText(metaUrl, 64 * 1024))
                sha = cleanSha(m.optString("sha256"))
                if (m.has("versionCode")) vCode = m.optLong("versionCode")
                vName = m.optString("versionName", vName).ifEmpty { vName }
            } catch (_: Exception) {
            }
        }
        if (sha == null && shaUrl != null) {
            try {
                sha = cleanSha(Net.getText(shaUrl, 4096).trim().split(Regex("\\s+")).firstOrNull())
            } catch (_: Exception) {
            }
        }
        return ReleaseInfo(
            tag, vName, o.optString("name", tag).ifEmpty { tag }, o.optString("body"), apkUrl, apkSize,
            o.optString("html_url"), o.optString("published_at"), sha, vCode
        )
    }

    private fun parts(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V").split('.', '-', '+').map { it.toIntOrNull() ?: 0 }

    fun nameIsNewer(remote: String, local: String): Boolean {
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** versionCode is authoritative when the release publishes it; otherwise compare version names. */
    fun isNewer(rel: ReleaseInfo, localName: String, localCode: Long): Boolean {
        val rc = rel.versionCode
        return if (rc != null) rc > localCode else nameIsNewer(rel.versionName, localName)
    }
}

/** Gradient catalog that can refresh independently of APK updates. */
object Catalog {
    private const val FILE = "catalog.json"

    fun loadCached(ctx: Context) {
        val f = File(ctx.filesDir, FILE)
        if (f.exists() && f.length() < 512 * 1024) {
            try {
                Gradients.extra = parse(f.readText())
            } catch (_: Exception) {
            }
        }
    }

    fun parse(json: String): List<GradientSpec> {
        val arr = JSONObject(json).optJSONArray("gradients") ?: return emptyList()
        val out = ArrayList<GradientSpec>()
        for (i in 0 until minOf(arr.length(), 200)) {
            try {
                out.add(GradientSpec.fromJson(arr.getJSONObject(i)))
            } catch (_: Exception) {
            }
        }
        return out
    }

    /** Blocking. Returns number of gradients loaded. */
    fun refresh(ctx: Context): Int {
        val text = Net.getText(BuildConfig.CATALOG_URL)
        val list = parse(text)
        File(ctx.filesDir, FILE).writeText(text)
        Gradients.extra = list
        return list.size
    }
}
