package com.rotex.theme

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object Pal {
    var dark = false
    val bg: Int get() = if (dark) 0xFF0D1020.toInt() else 0xFFF3F4FA.toInt()
    val card: Int get() = if (dark) 0xFF181C33.toInt() else 0xFFFFFFFF.toInt()
    val field: Int get() = if (dark) 0xFF252A4A.toInt() else 0xFFE9EBF7.toInt()
    val ink: Int get() = if (dark) 0xFFF1F3FF.toInt() else 0xFF191F37.toInt()
    val sub: Int get() = if (dark) 0xFF9AA1C2.toInt() else 0xFF666C84.toInt()
    val accent: Int get() = 0xFF5265FF.toInt()
    val danger: Int get() = 0xFFE5484D.toInt()
}

class GradientView(context: Context) : View(context) {
    var spec: GradientSpec? = null
        set(value) {
            field = value
            invalidate()
        }
    var radiusPx = 0f
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = spec ?: return
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        path.reset()
        path.addRoundRect(rect, radiusPx, radiusPx, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)
        s.draw(canvas, width.toFloat(), height.toFloat())
        canvas.restore()
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(color: Int, radiusDp: Int = 18): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = dp(radiusDp).toFloat()
    return d
}

fun Context.label(t: String, size: Int = 14, color: Int = Pal.ink, bold: Boolean = false): TextView {
    val tv = TextView(this)
    tv.text = t
    tv.textSize = size.toFloat()
    tv.setTextColor(color)
    tv.letterSpacing = 0.01f
    if (bold) tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    return tv
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.setPadding(dp(16), dp(15), dp(16), dp(15))
    c.background = rounded(Pal.card, 22)
    c.elevation = dp(2).toFloat()
    return c
}

fun Context.btn(t: String, filled: Boolean = true, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = t
    b.isAllCaps = false
    b.textSize = 14f
    b.setTextColor(if (filled) 0xFFFFFFFF.toInt() else Pal.accent)
    b.background = rounded(if (filled) Pal.accent else Pal.field, 14)
    b.stateListAnimator = null
    b.minWidth = 0
    b.minimumWidth = 0
    b.minHeight = 0
    b.minimumHeight = 0
    b.setPadding(dp(14), dp(11), dp(14), dp(11))
    b.setOnClickListener { onClick() }
    b.pressable()
    return b
}

fun Context.emptyState(glyph: String, title: String, sub: String): View {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.gravity = Gravity.CENTER
    box.setPadding(dp(24), dp(36), dp(24), dp(36))
    val g = label(glyph, 28, 0xFFFFFFFF.toInt(), true)
    g.gravity = Gravity.CENTER
    g.background = rounded(Pal.accent, 28)
    box.addView(g, LinearLayout.LayoutParams(dp(64), dp(64)))
    val t = label(title, 17, Pal.ink, true)
    t.gravity = Gravity.CENTER
    t.setPadding(0, dp(14), 0, dp(4))
    box.addView(t)
    val d = label(sub, 13, Pal.sub)
    d.gravity = Gravity.CENTER
    box.addView(d)
    return box
}

fun Context.lp(w: Int = -1, h: Int = -2, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h)
    p.topMargin = dp(top)
    p.bottomMargin = dp(bottom)
    return p
}

fun watcher(onChange: (String) -> Unit): TextWatcher = object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    override fun afterTextChanged(s: Editable?) {
        onChange(s?.toString().orEmpty())
    }
}

/** Grid of tappable gradient swatches (used by Studio and Wallpapers). */
fun Context.gradientGrid(specs: List<GradientSpec>, cols: Int, tileHeightDp: Int, onPick: (GradientSpec) -> Unit): View {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    for (rowSpecs in specs.chunked(cols)) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until cols) {
            val s = rowSpecs.getOrNull(i)
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.setPadding(dp(4), dp(4), dp(4), dp(4))
            if (s != null) {
                val gv = GradientView(this)
                gv.radiusPx = dp(14).toFloat()
                gv.spec = s
                cell.addView(gv, LinearLayout.LayoutParams(-1, dp(tileHeightDp)))
                val name = label(s.name, 11, Pal.sub)
                name.gravity = Gravity.CENTER
                name.maxLines = 1
                name.setPadding(0, dp(4), 0, 0)
                cell.addView(name)
                cell.setOnClickListener { onPick(s) }
            }
            row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(row)
    }
    return col
}

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : android.view.ViewOutlineProvider() {
        override fun getOutline(view: View, outline: android.graphics.Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}
