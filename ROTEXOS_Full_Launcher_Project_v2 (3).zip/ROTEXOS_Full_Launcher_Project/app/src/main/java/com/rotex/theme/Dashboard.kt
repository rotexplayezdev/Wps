package com.rotex.theme

import android.content.Intent
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.provider.Settings

private val HERO = listOf(0xFF1B2BFF.toInt(), 0xFF7B3CFF.toInt(), 0xFF00C6FF.toInt())

internal fun MainActivity.heroCard(title: String, sub: String, third: String? = null): View {
    val f = FrameLayout(this)
    val gv = GradientView(this)
    gv.radiusPx = dp(24).toFloat()
    gv.spec = GradientSpec("hero", HERO, 135)
    f.addView(gv, FrameLayout.LayoutParams(-1, -1))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(22), dp(20), dp(22), dp(20))
    col.addView(label(title, 26, 0xFFFFFFFF.toInt(), true))
    col.addView(label(sub, 13, 0xDDFFFFFF.toInt()).apply { setPadding(0, dp(4), 0, 0) })
    if (third != null) col.addView(label(third, 12, 0xBBFFFFFF.toInt()).apply { setPadding(0, dp(10), 0, 0) })
    f.addView(col, FrameLayout.LayoutParams(-1, -2))
    return f
}

private fun MainActivity.tile(title: String, sub: String, page: String): View {
    val c = card()
    val g = label(title.take(1), 18, 0xFFFFFFFF.toInt(), true)
    g.gravity = Gravity.CENTER
    g.background = rounded(Pal.accent, 14)
    c.addView(g, LinearLayout.LayoutParams(dp(40), dp(40)))
    c.addView(label(title, 15, Pal.ink, true).apply { setPadding(0, dp(10), 0, 0) })
    c.addView(label(sub, 11, Pal.sub))
    c.setOnClickListener { showPage(page) }
    c.pressable()
    return c
}

private fun MainActivity.tileGrid(items: List<Triple<String, String, String>>): View {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    for (pair in items.chunked(2)) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until 2) {
            val it = pair.getOrNull(i)
            val cell = LinearLayout(this)
            cell.setPadding(dp(5), dp(5), dp(5), dp(5))
            if (it != null) cell.addView(tile(it.first, it.second, it.third), LinearLayout.LayoutParams(-1, -2))
            row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(row)
    }
    return col
}

private fun MainActivity.rowCard(title: String, sub: String, page: String) {
    val c = card()
    c.addView(label(title, 16, Pal.ink, true))
    c.addView(label(sub, 12, Pal.sub).apply { setPadding(0, dp(3), 0, 0) })
    c.setOnClickListener { showPage(page) }
    c.pressable()
    content.addView(c, lp(bottom = 10))
}

internal fun MainActivity.homePage() {
    content.addView(heroCard("ROTEXOS", "Launcher \u2022 Theme Gallery \u2022 Developer Suite", "v${BuildConfig.VERSION_NAME}  \u2022  Made by Mahin"), lp(bottom = 12))
    if (!isDefaultLauncher()) {
        addCard("Make ROTEXOS your Home", "Choose ROTEXOS as the default Home app to use it as your launcher.", "Set as default launcher") {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
    }
    val avail = prefs.getString("update_available", "") ?: ""
    if (avail.isNotEmpty() && Updater.nameIsNewer(avail, BuildConfig.VERSION_NAME)) {
        addCard("Update available: v$avail", "A newer ROTEXOS release is on GitHub.", "Open Update Center") { showPage("Updates") }
    }
    val pinBox = LinearLayout(this)
    pinBox.orientation = LinearLayout.VERTICAL
    content.addView(pinBox)
    loadApps { apps ->
        val list = pinnedPackages().mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        if (list.isNotEmpty()) {
            val c = card()
            c.addView(label("Pinned apps", 17, Pal.ink, true))
            c.addView(appGrid(list))
            pinBox.addView(c, lp(bottom = 12))
        }
    }
    content.addView(
        tileGrid(
            listOf(
                Triple("Apps", "All installed apps", "Apps"),
                Triple("Theme Gallery", "Independent theme previews", "Gallery"),
                Triple("Developer Tools", "API, JSON, regex, hash, color", "Tools"),
                Triple("Terminal", "Sandboxed shell", "Terminal"),
                Triple("Theme Manager", "Import and export MTZ", "Themes"),
                Triple("Update Center", "GitHub releases", "Updates")
            )
        )
    )
    val credit = label("Made by Mahin  \u2022  TikTok: Your_Mahin001", 12, Pal.sub)
    credit.gravity = Gravity.CENTER
    content.addView(credit, lp(top = 6))
}

internal fun MainActivity.morePage() {
    rowCard("Theme Manager", "Import, validate and export .mtz theme packs", "Themes")
    rowCard("Gradient Studio", "Design gradient wallpapers and export them as .mtz", "Studio")
    rowCard("Wallpapers", "Apply gradients or your own image to home / lock screen", "Wallpapers")
    rowCard("Update Center", "Check GitHub releases, verify and install updates", "Updates")
    rowCard("Settings", "Appearance, grid, launcher, catalog, permissions", "Settings")
    rowCard("About ROTEXOS", "Version, developer and project information", "About")
}

internal fun MainActivity.settingsPage() {
    val modes = arrayOf("System", "Light", "Dark")
    val cur = prefs.getString("mode", "system") ?: "system"
    addCard("Appearance", "ROTEXOS app UI: ${cur.replaceFirstChar { it.uppercase() }}. Theme Gallery choices never change this.", "Change light / dark mode") {
        dialog().setTitle("Appearance").setItems(modes) { _, i ->
            prefs.edit().putString("mode", modes[i].lowercase()).apply()
            applyThemeMode()
            showPage("Settings")
        }.show()
    }
    addCard("App grid", "Columns in the app drawer and pinned apps: ${prefs.getInt("cols", 4)}", "Change columns") {
        dialog().setTitle("Columns").setItems(arrayOf("3", "4", "5")) { _, i ->
            prefs.edit().putInt("cols", i + 3).apply()
            appCache = null
            showPage("Settings")
        }.show()
    }
    addCard("Default launcher", if (isDefaultLauncher()) "ROTEXOS is your Home app." else "ROTEXOS is not the default Home app yet.", "Open Home settings") {
        startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
    }
    addCard("Default theme author", "Used when you export themes: ${studio.author.ifEmpty { "(not set)" }}", "Edit author") {
        prompt("Author name", studio.author) {
            studio.author = it.trim()
            prefs.edit().putString("author", studio.author).apply()
            showPage("Settings")
        }
    }
    val upd = addCard("Updates", "Installed v${BuildConfig.VERSION_NAME}. Updates are checked on GitHub Releases.", "Open Update Center") { showPage("Updates") }
    val auto = CheckBox(this)
    auto.text = "Check automatically (every 12 hours)"
    auto.setTextColor(Pal.ink)
    auto.isChecked = prefs.getBoolean("auto_update", true)
    auto.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("auto_update", on).apply() }
    upd.addView(auto, lp(top = 6))
    addCard("Gradient catalog", "Download new gradient presets from your repository without updating the APK. ${Gradients.extra.size} online presets loaded.", "Refresh catalog") {
        toast("Refreshing catalog...")
        runBg({ runCatching { Catalog.refresh(this) } }) { r ->
            r.onSuccess { toast("Catalog updated: $it presets") }.onFailure { toast("Catalog refresh failed: ${it.message ?: "network error"}") }
        }
    }
    addCard(
        "Permissions & privacy",
        "INTERNET: update check, catalog refresh, API Tester, terminal curl.\n" +
            "REQUEST_INSTALL_PACKAGES: lets Android's installer open downloaded ROTEXOS updates (you always confirm).\n" +
            "SET_WALLPAPER: apply wallpapers you choose.\n" +
            "REQUEST_DELETE_PACKAGES: open Android's uninstall prompt from the app menu.\n" +
            "Cleartext http:// is enabled so the API Tester can reach local servers; updates themselves are HTTPS-only.\n" +
            "App list uses a package-visibility <queries> entry. Files use the system picker; no storage permission."
    )
    addCard("About ROTEXOS", "Version, developer and project information.", "Open About") { showPage("About") }
}

internal fun MainActivity.aboutPage() {
    content.addView(heroCard("Made by Mahin", "TikTok: Your_Mahin001", "ROTEXOS ${BuildConfig.VERSION_NAME}"), lp(bottom = 12))
    addCard("Follow", "TikTok: Your_Mahin001", "Open TikTok profile") { openUrl("https://www.tiktok.com/@Your_Mahin001") }
    addCard(
        "App Version",
        "${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})\nPackage: $packageName\nUpdates: github.com/${updOwner()}/${updRepo()}"
    )
    addCard(
        "Project",
        "A Kotlin Android launcher with an independent Theme Gallery, MTZ theme manager, ten developer tools, a sandboxed terminal and a GitHub Releases updater. Built with native Android views, OkHttp and AndroidX Core."
    )
    addCard(
        "Honest limits",
        "ROTEXOS exports and imports MTZ files and hands them to the Xiaomi Themes app. It cannot force-apply system-wide Xiaomi themes, replace the lock screen, bypass signature checks or silently install updates."
    )
}
