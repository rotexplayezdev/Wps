package com.rotex.theme

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.max

/**
 * Draws a phone mockup of a gallery theme.
 * page: 0 home, 1 widgets, 2 app grid, 3 custom layout, 4 lock-screen CONCEPT.
 * This is a drawing only; it never changes ROTEXOS or Android.
 * "Glass" is simulated with a downscaled copy of the wallpaper + tint (not real-time blur).
 */
class PhonePreviewView(context: Context, private val theme: ThemeDef, private val page: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val src = Rect()
    private val screen = RectF()
    private var wall: Bitmap? = null
    private var soft: Bitmap? = null

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 2.05f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val rim = w * 0.035f
        screen.set(rim, rim, w - rim, h - rim)
        val sw = max(60, (screen.width() / 2f).toInt())
        val sh = max(120, (screen.height() / 2f).toInt())
        val wb = ThemeArt.bitmap(theme, sw, sh)
        wall = wb
        soft = Bitmap.createScaledBitmap(wb, max(2, sw / 12), max(2, sh / 12), true)
    }

    private fun gx(f: Float) = screen.left + screen.width() * f
    private fun gy(f: Float) = screen.top + screen.height() * f

    private fun tintColor(): Int = (theme.glassAlpha shl 24) or (theme.glassTint and 0xFFFFFF)

    private fun glass(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b)
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        val s = soft
        if (s != null) {
            src.set(
                ((l - screen.left) / screen.width() * s.width).toInt().coerceIn(0, s.width - 1),
                ((t - screen.top) / screen.height() * s.height).toInt().coerceIn(0, s.height - 1),
                ((r - screen.left) / screen.width() * s.width).toInt().coerceIn(1, s.width),
                ((b - screen.top) / screen.height() * s.height).toInt().coerceIn(1, s.height)
            )
            c.drawBitmap(s, src, rect, bmpPaint)
        }
        paint.style = Paint.Style.FILL
        paint.color = tintColor()
        c.drawRect(rect, paint)
        paint.shader = LinearGradient(l, t, l, b, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(rect, paint)
        paint.shader = null
        c.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width * 0.004f
        paint.color = 0x59FFFFFF
        c.drawRoundRect(rect, rad, rad, paint)
        paint.style = Paint.Style.FILL
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, light: Boolean = false, center: Boolean = false) {
        paint.style = Paint.Style.FILL
        paint.color = theme.ink
        paint.textSize = size
        paint.typeface = Typeface.create(if (light) "sans-serif-light" else "sans-serif-medium", Typeface.NORMAL)
        paint.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(s, x, y, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun glyph(c: Canvas, cx: Float, cy: Float, size: Float, idx: Int) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = size * 0.07f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = theme.ink
        val r = size * 0.2f
        when (idx % 6) {
            0 -> c.drawCircle(cx, cy, r, paint)
            1 -> {
                c.drawCircle(cx, cy, r * 1.15f, paint)
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.4f, paint)
            }
            2 -> {
                rect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawRoundRect(rect, r * 0.3f, r * 0.3f, paint)
            }
            3 -> {
                path.reset()
                path.moveTo(cx, cy - r)
                path.lineTo(cx + r, cy + r)
                path.lineTo(cx - r, cy + r)
                path.close()
                c.drawPath(path, paint)
            }
            4 -> {
                c.drawLine(cx - r, cy + r, cx - r, cy, paint)
                c.drawLine(cx, cy + r, cx, cy - r, paint)
                c.drawLine(cx + r, cy + r, cx + r, cy - r * 0.4f, paint)
            }
            else -> {
                c.drawLine(cx - r, cy, cx + r, cy, paint)
                c.drawLine(cx, cy - r, cx, cy + r, paint)
            }
        }
        paint.style = Paint.Style.FILL
    }

    private fun icon(c: Canvas, cx: Float, cy: Float, size: Float, idx: Int) {
        glass(c, cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2, size * 0.28f)
        glyph(c, cx, cy, size, idx)
    }

    private fun iconGrid(c: Canvas, topF: Float, stepF: Float, rows: Int) {
        val size = screen.width() * 0.17f
        var n = 0
        for (i in 0 until rows) for (j in 0 until 4) {
            icon(c, gx(0.14f + 0.24f * j), gy(topF + stepF * i), size, n++)
        }
    }

    private fun dock(c: Canvas) {
        glass(c, gx(0.05f), gy(0.875f), gx(0.95f), gy(0.975f), screen.width() * 0.12f)
        val size = screen.width() * 0.15f
        for (j in 0 until 4) icon(c, gx(0.14f + 0.24f * j), gy(0.925f), size, j + 2)
    }

    private fun dots(c: Canvas, active: Int) {
        for (i in 0 until 4) {
            paint.style = Paint.Style.FILL
            paint.color = if (i == active) theme.ink else (theme.ink and 0xFFFFFF) or 0x66000000
            c.drawCircle(gx(0.5f + (i - 1.5f) * 0.07f), gy(0.845f), screen.width() * 0.012f, paint)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        paint.style = Paint.Style.FILL
        paint.color = 0xFF0B0C10.toInt()
        c.drawRoundRect(rect, w * 0.16f, w * 0.16f, paint)
        val wb = wall ?: return
        path.reset()
        path.addRoundRect(screen, w * 0.13f, w * 0.13f, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        c.drawBitmap(wb, null, screen, bmpPaint)
        txt(c, "9:41", gx(0.07f), gy(0.035f), screen.width() * 0.06f)
        when (page) {
            0 -> drawHome(c)
            1 -> drawWidgets(c)
            2 -> {
                iconGrid(c, 0.09f, 0.125f, 6)
                dots(c, 2)
                dock(c)
            }
            3 -> drawCustom(c)
            else -> drawLock(c)
        }
        c.restore()
    }

    private fun drawHome(c: Canvas) {
        val sw = screen.width()
        glass(c, gx(0.06f), gy(0.06f), gx(0.94f), gy(0.25f), sw * 0.1f)
        txt(c, "12:32", gx(0.12f), gy(0.17f), sw * 0.2f, true)
        txt(c, "Tue 24 Nov", gx(0.12f), gy(0.22f), sw * 0.055f)
        iconGrid(c, 0.33f, 0.105f, 3)
        glass(c, gx(0.06f), gy(0.65f), gx(0.94f), gy(0.77f), sw * 0.08f)
        glyph(c, gx(0.15f), gy(0.71f), sw * 0.2f, 3)
        for (i in 0 until 5) glyph(c, gx(0.35f + 0.1f * i), gy(0.71f), sw * 0.1f, 4)
        dots(c, 0)
        dock(c)
    }

    private fun drawWidgets(c: Canvas) {
        val sw = screen.width()
        glass(c, gx(0.06f), gy(0.06f), gx(0.94f), gy(0.34f), sw * 0.08f)
        txt(c, "NOVEMBER", gx(0.12f), gy(0.1f), sw * 0.05f)
        for (r in 0 until 5) for (q in 0 until 7) {
            paint.style = Paint.Style.FILL
            paint.color = if (r == 3 && q == 1) theme.accent else (theme.ink and 0xFFFFFF) or 0x55000000
            c.drawCircle(gx(0.14f + 0.12f * q), gy(0.15f + 0.04f * r), sw * 0.018f, paint)
        }
        glass(c, gx(0.06f), gy(0.37f), gx(0.5f), gy(0.55f), sw * 0.08f)
        txt(c, "24\u00B0", gx(0.12f), gy(0.47f), sw * 0.14f, true)
        glass(c, gx(0.53f), gy(0.37f), gx(0.94f), gy(0.55f), sw * 0.08f)
        glyph(c, gx(0.735f), gy(0.46f), sw * 0.3f, 1)
        glass(c, gx(0.06f), gy(0.58f), gx(0.94f), gy(0.72f), sw * 0.08f)
        glyph(c, gx(0.15f), gy(0.65f), sw * 0.2f, 3)
        for (i in 0 until 6) glyph(c, gx(0.34f + 0.09f * i), gy(0.65f), sw * 0.1f, 4)
        glass(c, gx(0.06f), gy(0.75f), gx(0.94f), gy(0.9f), sw * 0.08f)
        for (i in 0 until 7) {
            paint.style = Paint.Style.FILL
            paint.color = theme.accent
            val bh = sw * (0.05f + 0.04f * ((i * 5) % 4))
            c.drawRoundRect(gx(0.13f + 0.11f * i), gy(0.86f) - bh, gx(0.13f + 0.11f * i) + sw * 0.06f, gy(0.86f), sw * 0.02f, sw * 0.02f, paint)
        }
        dots(c, 1)
    }

    private fun drawCustom(c: Canvas) {
        val sw = screen.width()
        rect.set(gx(0.06f), gy(0.06f), gx(0.94f), gy(0.34f))
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, theme.palette[1], theme.palette[3], Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, sw * 0.08f, sw * 0.08f, paint)
        paint.shader = null
        txt(c, theme.name, gx(0.1f), gy(0.31f), sw * 0.06f)
        glass(c, gx(0.06f), gy(0.37f), gx(0.5f), gy(0.53f), sw * 0.08f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw * 0.012f
        paint.color = theme.ink
        c.drawCircle(gx(0.28f), gy(0.45f), sw * 0.12f, paint)
        c.drawLine(gx(0.28f), gy(0.45f), gx(0.28f), gy(0.4f), paint)
        c.drawLine(gx(0.28f), gy(0.45f), gx(0.34f), gy(0.46f), paint)
        glass(c, gx(0.53f), gy(0.37f), gx(0.94f), gy(0.53f), sw * 0.08f)
        glyph(c, gx(0.735f), gy(0.45f), sw * 0.28f, 5)
        iconGrid(c, 0.62f, 0.105f, 2)
        dots(c, 3)
        dock(c)
    }

    private fun drawLock(c: Canvas) {
        val sw = screen.width()
        txt(c, "7:15", gx(0.5f), gy(0.22f), sw * 0.34f, true, true)
        txt(c, "Friday 22 January", gx(0.5f), gy(0.27f), sw * 0.07f, false, true)
        glass(c, gx(0.1f), gy(0.86f), gx(0.26f), gy(0.86f) + sw * 0.16f, sw * 0.08f)
        glass(c, gx(0.74f), gy(0.86f), gx(0.9f), gy(0.86f) + sw * 0.16f, sw * 0.08f)
        txt(c, "CONCEPT PREVIEW", gx(0.5f), gy(0.95f), sw * 0.045f, false, true)
    }
}

/** Wide strip showing a wallpaper crop plus six glass icons. */
class IconStripView(context: Context, private val theme: ThemeDef) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 0.3f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val wb = ThemeArt.bitmap(theme, 180, 360)
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, h * 0.22f, h * 0.22f, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        val sy = (wb.height * 0.35f).toInt()
        val sh = (wb.width * h / w).toInt().coerceAtMost(wb.height - sy)
        c.drawBitmap(wb, Rect(0, sy, wb.width, sy + sh), rect, Paint(Paint.FILTER_BITMAP_FLAG))
        for (i in 0 until 6) {
            val cx = w * (0.1f + 0.16f * i)
            val s = h * 0.5f
            rect.set(cx - s / 2, h / 2 - s / 2, cx + s / 2, h / 2 + s / 2)
            paint.style = Paint.Style.FILL
            paint.color = (theme.glassAlpha shl 24) or (theme.glassTint and 0xFFFFFF)
            c.drawRoundRect(rect, s * 0.28f, s * 0.28f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = s * 0.06f
            paint.color = theme.ink
            c.drawCircle(cx, h / 2, s * (0.12f + 0.03f * (i % 3)), paint)
        }
        c.restore()
    }
}
