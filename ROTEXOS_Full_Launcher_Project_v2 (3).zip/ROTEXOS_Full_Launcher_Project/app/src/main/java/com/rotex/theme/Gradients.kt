package com.rotex.theme

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

enum class GType {
    LINEAR, RADIAL, SWEEP;

    companion object {
        fun parse(s: String?): GType = when (s?.lowercase(Locale.US)) {
            "radial" -> RADIAL
            "sweep" -> SWEEP
            else -> LINEAR
        }
    }
}

fun hex(c: Int): String = String.format(Locale.US, "#%06X", c and 0xFFFFFF)

private fun isHexChar(c: Char) = c in '0'..'9' || c in 'a'..'f' || c in 'A'..'F'

/** Parses "#RGB", "#RRGGBB" (with or without '#'). Returns null when invalid. */
fun parseHex(s: String): Int? {
    var t = s.trim().removePrefix("#")
    if (t.length == 3) t = t.map { "$it$it" }.joinToString("")
    if (t.length != 6 || !t.all { isHexChar(it) }) return null
    return (0xFF000000L or t.toLong(16)).toInt()
}

data class GradientSpec(
    val name: String,
    val colors: List<Int>,
    val angle: Int = 135,
    val type: GType = GType.LINEAR
) {
    /** Angle convention: 0 = left->right, 90 = top->bottom. */
    fun draw(canvas: Canvas, w: Float, h: Float) {
        val base = if (colors.size >= 2) colors else listOf(colors.firstOrNull() ?: 0xFF000000.toInt(), colors.firstOrNull() ?: 0xFF000000.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = when (type) {
            GType.LINEAR -> {
                val r = Math.toRadians(angle.toDouble())
                val half = (abs(w * cos(r)) + abs(h * sin(r))) / 2.0
                val dx = (cos(r) * half).toFloat()
                val dy = (sin(r) * half).toFloat()
                LinearGradient(w / 2 - dx, h / 2 - dy, w / 2 + dx, h / 2 + dy, base.toIntArray(), null, Shader.TileMode.CLAMP)
            }
            GType.RADIAL -> RadialGradient(w / 2, h / 2, max(w, h) * 0.75f, base.toIntArray(), null, Shader.TileMode.CLAMP)
            GType.SWEEP -> SweepGradient(w / 2, h / 2, (base + base.first()).toIntArray(), null)
        }
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    fun toBitmap(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), w.toFloat(), h.toFloat())
        return bmp
    }

    fun toJson(author: String = ""): JSONObject {
        val o = JSONObject()
        o.put("format", "rotexos-theme")
        o.put("version", 1)
        o.put("name", name)
        o.put("author", author)
        o.put("type", type.name.lowercase(Locale.US))
        o.put("angle", angle)
        o.put("colors", JSONArray(colors.map { hex(it) }))
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): GradientSpec {
            val arr = o.optJSONArray("colors") ?: throw IllegalArgumentException("Missing 'colors'")
            if (arr.length() < 2 || arr.length() > 5) throw IllegalArgumentException("A gradient needs 2 to 5 colors")
            val cols = (0 until arr.length()).map {
                parseHex(arr.optString(it)) ?: throw IllegalArgumentException("Invalid color: ${arr.optString(it)}")
            }
            val name = o.optString("name", "Imported gradient").trim().take(40).ifEmpty { "Imported gradient" }
            return GradientSpec(name, cols, ((o.optInt("angle", 135) % 360) + 360) % 360, GType.parse(o.optString("type")))
        }
    }
}

object Gradients {
    @Volatile
    var extra: List<GradientSpec> = emptyList()

    fun all(): List<GradientSpec> = builtin + extra

    private fun g(name: String, angle: Int, vararg hexes: String, type: GType = GType.LINEAR) =
        GradientSpec(name, hexes.map { parseHex(it)!! }, angle, type)

    val builtin: List<GradientSpec> = listOf(
        g("Aurora", 135, "#00C6FF", "#0072FF"),
        g("Sunset Blaze", 120, "#FF512F", "#DD2476"),
        g("Ocean Deep", 160, "#0F2027", "#203A43", "#2C5364"),
        g("Neon Rotex", 90, "#0A0A0A", "#0D3B1E", "#00FF66"),
        g("Midnight City", 135, "#232526", "#414345"),
        g("Lavender Haze", 135, "#A18CD1", "#FBC2EB"),
        g("Mint Fresh", 135, "#11998E", "#38EF7D"),
        g("Cherry Cola", 135, "#EB3349", "#F45C43"),
        g("Golden Hour", 120, "#F7971E", "#FFD200"),
        g("Arctic", 160, "#E0EAFC", "#CFDEF3"),
        g("Cosmic", 135, "#41295A", "#2F0743"),
        g("Peach", 135, "#FFECD2", "#FCB69F"),
        g("Emerald", 135, "#134E5E", "#71B280"),
        g("Carbon", 90, "#141E30", "#243B55"),
        g("Rose Gold", 135, "#ED4264", "#FFEDBC"),
        g("Cyber Lime", 45, "#D4FC79", "#96E6A1"),
        g("Twilight", 160, "#1D2B64", "#F8CDDA"),
        g("Lagoon", 135, "#43C6AC", "#191654"),
        g("Ember", 90, "#200122", "#6F0000"),
        g("Frost", 135, "#83A4D4", "#B6FBFF"),
        g("Blueberry", 135, "#4776E6", "#8E54E9"),
        g("Candy", 135, "#FF9A9E", "#FAD0C4"),
        g("Matcha", 135, "#76B852", "#8DC26F"),
        g("Dawn Sky", 150, "#FF9966", "#FF5E62", "#7F00FF"),
        g("Obsidian Glow", 0, "#3A3A52", "#000000", type = GType.RADIAL),
        g("Solar Flare", 0, "#FFE259", "#FFA751", type = GType.RADIAL),
        g("Nebula", 0, "#8E2DE2", "#4A00E0", type = GType.RADIAL),
        g("Prism", 0, "#FF5F6D", "#FFC371", "#47E1B4", "#5B86E5", type = GType.SWEEP)
    )
}
