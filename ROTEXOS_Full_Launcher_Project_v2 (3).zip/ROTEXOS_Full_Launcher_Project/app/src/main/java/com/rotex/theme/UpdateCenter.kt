package com.rotex.theme

import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal fun MainActivity.updatesPage() {
    val owner = updOwner()
    val repo = updRepo()
    val configured = Updater.isConfigured(owner)

    val v = card()
    v.addView(label("Version", 17, Pal.ink, true))
    v.addView(label("Installed: ${BuildConfig.VERSION_NAME} (code ${BuildConfig.VERSION_CODE})", 14, Pal.ink).apply { setPadding(0, dp(8), 0, 0) })
    val latestLabel = label("Latest: not checked yet", 14, Pal.ink)
    latestLabel.setPadding(0, dp(4), 0, 0)
    v.addView(latestLabel)
    val chip = label("NOT CHECKED", 11, 0xFFFFFFFF.toInt(), true)
    chip.background = rounded(Pal.sub, 10)
    chip.setPadding(dp(10), dp(4), dp(10), dp(4))
    v.addView(chip, lp(-2, -2, top = 8))
    if (BuildConfig.DEBUG) {
        v.addView(
            label(
                "This is a debug build (${packageName}). Release updates are a separate signed app (com.rotex.theme) and will not replace this build. Install the signed release APK once to receive in-place updates.",
                11, Pal.sub
            ).apply { setPadding(0, dp(8), 0, 0) }
        )
    }
    content.addView(v, lp(bottom = 12))

    val r = card()
    r.addView(label("Repository", 17, Pal.ink, true))
    r.addView(
        label(if (configured) "github.com/$owner/$repo" else "Not configured. Set it below (owner/repo).", 13, if (configured) Pal.ink else Pal.danger)
            .apply { setPadding(0, dp(6), 0, dp(8)) }
    )
    r.addView(btn("Change repository", false) {
        prompt("GitHub repository (owner/repo)", "$owner/$repo") { text ->
            val parts = text.trim().split('/')
            if (parts.size == 2 && Regex("[A-Za-z0-9._-]{1,100}").matches(parts[0]) && Regex("[A-Za-z0-9._-]{1,100}").matches(parts[1])) {
                prefs.edit().putString("upd_owner", parts[0]).putString("upd_repo", parts[1]).apply()
                latestRelease = null
                showPage("Updates")
            } else {
                toast("Use the format owner/repo")
            }
        }
    })
    content.addView(r, lp(bottom = 12))

    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL

    fun renderRelease() {
        box.removeAllViews()
        val rel = latestRelease ?: return
        val newer = Updater.isNewer(rel, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE.toLong())
        latestLabel.text = "Latest: ${rel.versionName} (${rel.tag})"
        chip.text = if (newer) "UPDATE AVAILABLE" else "UP TO DATE"
        chip.background = rounded(if (newer) 0xFF2E9E5B.toInt() else Pal.sub, 10)
        val c = card()
        c.addView(label(rel.title, 17, Pal.ink, true))
        val meta = StringBuilder()
        if (rel.publishedAt.isNotEmpty()) meta.append("Published ").append(rel.publishedAt.take(10)).append("  \u2022  ")
        if (rel.apkSize > 0) meta.append(rel.apkSize / 1024).append(" KB")
        if (meta.isNotEmpty()) c.addView(label(meta.toString(), 12, Pal.sub).apply { setPadding(0, dp(4), 0, 0) })
        val sha = rel.sha256
        c.addView(
            label(
                if (sha != null) "SHA-256 published: ${sha.take(16)}..." else "No SHA-256 published for this release - installation is blocked.",
                12, if (sha != null) 0xFF2E9E5B.toInt() else Pal.danger
            ).apply { setPadding(0, dp(6), 0, dp(8)) }
        )
        c.addView(label("Release notes", 14, Pal.ink, true))
        val notes = TextView(this)
        notes.text = rel.notes.ifBlank { "No release notes." }.take(4000)
        notes.setTextColor(Pal.sub)
        notes.textSize = 12.5f
        notes.setTextIsSelectable(true)
        notes.setPadding(0, dp(4), 0, dp(10))
        c.addView(notes)
        if (newer && rel.apkUrl != null) c.addView(btn("Download & install") { startDownload(rel) })
        else if (newer) c.addView(btn("Open release page") { openUrl(rel.pageUrl) })
        box.addView(c)
    }

    val loading = LinearLayout(this)
    loading.orientation = LinearLayout.VERTICAL
    val check = btn("Check for updates") {
        if (!configured) {
            toast("Set the GitHub repository first")
        } else {
            loading.removeAllViews()
            loading.addView(DotsLoader(this))
            fetchLatestRelease { res ->
                loading.removeAllViews()
                res.onSuccess { renderRelease() }
                    .onFailure { loading.addView(label("Update check failed: ${it.message ?: "network error"}", 13, Pal.danger)) }
            }
        }
    }
    content.addView(check, lp(bottom = 8))
    content.addView(loading)
    content.addView(box)
    renderRelease()

    val h = card()
    h.addView(label("Update history", 17, Pal.ink, true))
    val arr = try {
        JSONArray(prefs.getString("upd_history", "[]") ?: "[]")
    } catch (_: Exception) {
        JSONArray()
    }
    if (arr.length() == 0) {
        h.addView(label("No update activity yet.", 12, Pal.sub).apply { setPadding(0, dp(6), 0, 0) })
    }
    val df = SimpleDateFormat("MMM dd HH:mm", Locale.US)
    for (i in 0 until minOf(arr.length(), 15)) {
        val o = arr.optJSONObject(i) ?: continue
        h.addView(label("${df.format(Date(o.optLong("t")))}  ${o.optString("m")}", 12, Pal.sub).apply { setPadding(0, dp(6), 0, 0) })
    }
    if (arr.length() > 0) {
        h.addView(btn("Clear history", false) {
            prefs.edit().putString("upd_history", "[]").apply()
            showPage("Updates")
        }, lp(top = 10))
    }
    content.addView(h, lp(top = 12, bottom = 12))
}
