package com.rotex.theme

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.text.SpannableStringBuilder
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

const val REQ_IMPORT_MTZ = 401
const val REQ_SAVE_EXPORT = 402
const val REQ_STUDIO_IMPORT = 403
const val REQ_WALLPAPER_IMAGE = 404
const val REQ_INSPECT_MTZ = 405
const val REQ_SAVE_JSON = 406

class AppEntry(val label: String, val pkg: String, val icon: Drawable)

class StudioState {
    var name = "My Gradient Theme"
    var author = ""
    var colors: MutableList<Int> = mutableListOf(0xFF00C6FF.toInt(), 0xFF0072FF.toInt())
    var angle = 135
    var type = GType.LINEAR
    var resChoice = 0

    fun spec() = GradientSpec(name.trim().ifEmpty { "ROTEXOS Theme" }, colors.toList(), angle, type)

    fun load(s: GradientSpec) {
        name = s.name
        colors = s.colors.toMutableList()
        angle = s.angle
        type = s.type
    }

    fun applyJson(json: String) {
        val o = JSONObject(json)
        load(GradientSpec.fromJson(o))
        author = o.optString("author", author)
    }

    fun size(dm: DisplayMetrics): Pair<Int, Int> = when (resChoice) {
        1 -> 1080 to 1920
        2 -> 1080 to 2400
        3 -> 1440 to 3200
        4 -> 720 to 1600
        else -> min(dm.widthPixels, dm.heightPixels) to max(dm.widthPixels, dm.heightPixels)
    }

    companion object {
        val RES_LABELS = arrayOf("This device", "1080 x 1920", "1080 x 2400", "1440 x 3200", "720 x 1600")
    }
}

class MainActivity : Activity() {
    internal lateinit var content: LinearLayout
    internal var currentPage = "Home"
    internal val prefs: SharedPreferences by lazy { getSharedPreferences("rotexos", MODE_PRIVATE) }
    internal val studio = StudioState()
    internal var appCache: List<AppEntry>? = null
    internal var pendingExport: File? = null
    internal var pendingText: String? = null
    private val navItems = listOf("Home", "Apps", "Gallery", "Tools", "Terminal", "More")

    internal var galleryQuery = ""
    internal var galleryCategory = "All"
    internal var selectedThemeId = ""
    internal val api = ApiState()
    internal val toolState = HashMap<String, String>()
    internal var colorValue = 0xFF5265FF.toInt()
    internal val workColors = ArrayList<Int>()
    internal val termText = SpannableStringBuilder()
    internal val shell: Shell by lazy { Shell(applicationContext) }
    internal val termExec = Executors.newSingleThreadExecutor()
    internal var termHistoryPos = 0
    internal var latestRelease: ReleaseInfo? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        Catalog.loadCached(this)
        studio.author = prefs.getString("author", "") ?: ""
        workColors.addAll((prefs.getString("work_palette", "") ?: "").split(',').mapNotNull { parseHex(it) })
        applyThemeMode()
        showPage("Home")
        maybeAutoCheckUpdates()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) showPage("Home")
    }

    override fun onRestart() {
        super.onRestart()
        appCache = null // pick up installs/uninstalls on next page render
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyThemeMode()
        showPage(currentPage)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // a launcher never exits: go to the parent page, then Home
        val target = parentOf(currentPage) ?: if (currentPage != "Home") "Home" else null
        if (target != null) showPage(target)
    }

    override fun onDestroy() {
        termExec.shutdown()
        super.onDestroy()
    }

    internal fun applyThemeMode() {
        Pal.dark = when (prefs.getString("mode", "system")) {
            "dark" -> true
            "light" -> false
            else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        ctl.isAppearanceLightStatusBars = !Pal.dark
        ctl.isAppearanceLightNavigationBars = !Pal.dark
    }

    internal fun parentOf(page: String): String? = when (page) {
        "GalleryDetail" -> "Gallery"
        "ToolApi", "ToolJson", "ToolRegex", "ToolEncode", "ToolColor" -> "Tools"
        "Themes", "Studio", "Wallpapers", "Updates", "Settings", "About" -> "More"
        else -> null
    }

    private fun navFor(page: String): String = when (page) {
        "Home", "Apps", "Gallery", "Tools", "Terminal", "More" -> page
        "GalleryDetail" -> "Gallery"
        "ToolApi", "ToolJson", "ToolRegex", "ToolEncode", "ToolColor" -> "Tools"
        else -> "More"
    }

    private fun titleFor(page: String): String = when (page) {
        "GalleryDetail" -> ThemeCatalog.find(selectedThemeId)?.name ?: "Theme"
        "Gallery" -> "Theme Gallery"
        "Tools" -> "Developer Tools"
        "ToolApi" -> "API Tester"
        "ToolJson" -> "JSON & YAML Studio"
        "ToolRegex" -> "Regex Playground"
        "ToolEncode" -> "Encoder & Hash"
        "ToolColor" -> "Color & Gradient"
        "Themes" -> "Theme Manager"
        "Studio" -> "Gradient Studio"
        "Updates" -> "Update Center"
        "About" -> "About ROTEXOS"
        else -> page
    }

    internal fun showPage(page: String) {
        currentPage = page
        val full = page == "Terminal"
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Pal.bg)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(14), dp(22), dp(8))
        val parent = parentOf(page)
        if (parent != null) {
            val back = label("\u2039 " + titleFor(parent), 13, Pal.accent, true)
            back.setPadding(0, 0, 0, dp(4))
            back.setOnClickListener { showPage(parent) }
            header.addView(back)
        } else {
            header.addView(label("ROTEXOS", 13, Pal.accent, true))
        }
        header.addView(label(titleFor(page), 26, Pal.ink, true))
        root.addView(header)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        if (full) {
            content.setPadding(dp(14), dp(4), dp(14), dp(10))
            root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            content.setPadding(dp(18), dp(6), dp(18), dp(20))
            val scroll = ScrollView(this)
            scroll.addView(content)
            root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(bottomNav())
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(140).start()

        when (page) {
            "Home" -> homePage()
            "Apps" -> appsPage()
            "Gallery" -> galleryPage()
            "GalleryDetail" -> galleryDetailPage()
            "Themes" -> themesPage()
            "Studio" -> studioPage()
            "Wallpapers" -> wallpapersPage()
            "Tools" -> toolsPage()
            "ToolApi" -> apiToolPage()
            "ToolJson" -> jsonToolPage()
            "ToolRegex" -> regexToolPage()
            "ToolEncode" -> encodeToolPage()
            "ToolColor" -> colorToolPage()
            "Terminal" -> terminalPage()
            "Updates" -> updatesPage()
            "More" -> morePage()
            "Settings" -> settingsPage()
            "About" -> aboutPage()
        }
        if (!full) {
            for (i in 0 until minOf(content.childCount, 8)) content.getChildAt(i).enterAnim(i)
        }
    }

    private fun bottomNav(): View {
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Pal.card)
        nav.setPadding(dp(2), dp(2), dp(2), dp(2))
        val active = navFor(currentPage)
        for (item in navItems) {
            val sel = item == active
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(0, dp(6), 0, dp(10))
            val bar = View(this)
            bar.background = rounded(if (sel) Pal.accent else 0, 2)
            cell.addView(bar, LinearLayout.LayoutParams(dp(22), dp(3)))
            val t = label(item, 11, if (sel) Pal.accent else Pal.sub, sel)
            t.setPadding(0, dp(7), 0, 0)
            cell.addView(t)
            cell.setOnClickListener { showPage(item) }
            cell.pressable()
            nav.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return nav
    }

    // ---------- shared helpers ----------

    internal fun addCard(title: String, sub: String, actionText: String? = null, action: (() -> Unit)? = null): LinearLayout {
        val c = card()
        c.addView(label(title, 17, Pal.ink, true))
        val s = label(sub, 13, Pal.sub)
        s.setPadding(0, dp(6), 0, dp(if (actionText != null) 10 else 0))
        c.addView(s)
        if (actionText != null && action != null) c.addView(btn(actionText, true, action))
        content.addView(c, lp(bottom = 12))
        return c
    }

    internal fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    internal fun <T> runBg(work: () -> T, done: (T) -> Unit) {
        Thread {
            val r = work()
            runOnUiThread { if (!isFinishing && !isDestroyed) done(r) }
        }.start()
    }

    internal fun dialog(): AlertDialog.Builder = AlertDialog.Builder(
        this,
        if (Pal.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
    )

    internal fun copyText(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ROTEXOS", t))
        toast("Copied to clipboard")
    }

    internal fun showText(title: String, body: String, extraLabel: String? = null, extra: (() -> Unit)? = null) {
        val tv = TextView(this)
        tv.text = body
        tv.textSize = 12f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(Pal.ink)
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(20), dp(8), dp(20), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        val b = dialog().setTitle(title).setView(sv)
            .setPositiveButton("Close", null)
            .setNegativeButton("Copy") { _, _ -> copyText(body) }
        if (extraLabel != null && extra != null) b.setNeutralButton(extraLabel) { _, _ -> extra() }
        b.show()
    }

    internal fun prompt(title: String, initial: String, onOk: (String) -> Unit) {
        val et = android.widget.EditText(this)
        et.setText(initial)
        et.setSingleLine(true)
        et.setTextColor(Pal.ink)
        val box = LinearLayout(this)
        box.setPadding(dp(22), dp(8), dp(22), 0)
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        dialog().setTitle(title).setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    internal fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            toast("No app can open this link")
        }
    }

    internal fun pickFile(req: Int, mime: String = "*/*") {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        try {
            startActivityForResult(i, req)
        } catch (_: Exception) {
            toast("No file picker available on this device")
        }
    }

    internal fun createDoc(req: Int, name: String, mime: String) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_TITLE, name)
        try {
            startActivityForResult(i, req)
        } catch (_: Exception) {
            toast("No file picker available on this device")
        }
    }

    internal fun shareFile(f: File, mime: String, chooserTitle: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val send = Intent(Intent.ACTION_SEND)
            send.type = mime
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, chooserTitle))
        } catch (e: Exception) {
            toast("Cannot share: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    internal fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return dm
    }

    @Suppress("DEPRECATION")
    internal fun refreshRate(): Float = windowManager.defaultDisplay.refreshRate

    internal fun isDefaultLauncher(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    internal fun loadApps(cb: (List<AppEntry>) -> Unit) {
        val cached = appCache
        if (cached != null) {
            cb(cached)
            return
        }
        runBg({
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }) { list ->
            appCache = list
            cb(list)
        }
    }

    // ---------- wallpapers ----------

    internal fun chooseWallpaperTarget(onChoose: (Int) -> Unit) {
        if (Build.VERSION.SDK_INT < 24) {
            onChoose(1)
            return
        }
        dialog().setTitle("Set wallpaper for")
            .setItems(arrayOf("Home screen", "Lock screen", "Both")) { _, i -> onChoose(if (i == 0) 1 else if (i == 1) 2 else 3) }
            .show()
    }

    internal fun applyWallpaper(provider: () -> Bitmap, which: Int) {
        toast("Applying wallpaper...")
        runBg({
            runCatching {
                val bmp = provider()
                try {
                    val wm = WallpaperManager.getInstance(applicationContext)
                    if (Build.VERSION.SDK_INT >= 24) {
                        var flags = 0
                        if ((which and 1) != 0) flags = flags or WallpaperManager.FLAG_SYSTEM
                        if ((which and 2) != 0) flags = flags or WallpaperManager.FLAG_LOCK
                        wm.setBitmap(bmp, null, true, flags)
                    } else {
                        wm.setBitmap(bmp)
                    }
                } finally {
                    bmp.recycle()
                }
            }
        }) { r ->
            r.onSuccess { toast("Wallpaper applied") }
                .onFailure { toast("Could not set wallpaper: ${it.message ?: "unknown error"}") }
        }
    }

    internal fun decodeUriBitmap(uri: Uri): Bitmap {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 4096) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalArgumentException("Could not read the selected image")
    }

    // ---------- live updates ----------

    internal fun updOwner(): String = prefs.getString("upd_owner", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GITHUB_OWNER

    internal fun updRepo(): String = prefs.getString("upd_repo", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GITHUB_REPO

    internal fun logUpdate(msg: String) {
        val arr = try {
            JSONArray(prefs.getString("upd_history", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val o = JSONObject()
        o.put("t", System.currentTimeMillis())
        o.put("m", msg)
        val next = JSONArray()
        next.put(o)
        for (i in 0 until minOf(arr.length(), 39)) next.put(arr.get(i))
        prefs.edit().putString("upd_history", next.toString()).apply()
    }

    internal fun fetchLatestRelease(onDone: (Result<ReleaseInfo>) -> Unit) {
        val owner = updOwner()
        val repo = updRepo()
        runBg({ runCatching { Updater.fetchLatest(owner, repo) } }) { r ->
            r.onSuccess { rel ->
                latestRelease = rel
                val newer = Updater.isNewer(rel, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE.toLong())
                prefs.edit().putString("update_available", if (newer) rel.versionName else "").apply()
                logUpdate("Checked: latest ${rel.tag}" + if (newer) " (newer than installed)" else " (up to date)")
            }.onFailure {
                logUpdate("Check failed: ${it.message ?: "network error"}")
            }
            onDone(r)
        }
    }

    private fun maybeAutoCheckUpdates() {
        if (!Updater.isConfigured(updOwner()) || !prefs.getBoolean("auto_update", true)) return
        val last = prefs.getLong("last_update_check", 0L)
        if (System.currentTimeMillis() - last < 12L * 3600 * 1000) return
        prefs.edit().putLong("last_update_check", System.currentTimeMillis()).apply()
        fetchLatestRelease { r ->
            r.onSuccess { rel ->
                if (Updater.isNewer(rel, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE.toLong())) {
                    toast("ROTEXOS update available: ${rel.tag}. Open Update Center.")
                    if (currentPage == "Home") showPage("Home")
                }
            }
        }
    }

    internal fun startDownload(rel: ReleaseInfo) {
        val url = rel.apkUrl ?: return
        val dest = File(File(cacheDir, "updates"), "ROTEXOS-${rel.tag.replace(Regex("[^A-Za-z0-9._-]"), "_")}.apk")
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        val txt = label("Starting...", 13, Pal.sub)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(12), dp(22), dp(4))
        box.addView(txt)
        box.addView(bar)
        val cancelled = AtomicBoolean(false)
        val dlg = dialog().setTitle("Downloading ${rel.tag}").setView(box).setCancelable(false)
            .setNegativeButton("Cancel") { _, _ -> cancelled.set(true) }.create()
        dlg.show()
        Thread {
            val r = runCatching {
                Net.download(url, dest, cancelled) { done, total ->
                    runOnUiThread {
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            bar.progress = p
                            txt.text = "$p%  (${done / 1024} / ${total / 1024} KB)"
                        } else {
                            txt.text = "${done / 1024} KB"
                        }
                    }
                }
            }
            runOnUiThread {
                if (dlg.isShowing) dlg.dismiss()
                r.onSuccess { verifyAndInstall(dest, rel) }.onFailure {
                    val m = if (cancelled.get()) "Download cancelled" else "Download failed: ${it.message ?: "unknown error"}"
                    logUpdate(m)
                    toast(m)
                }
            }
        }.start()
    }

    private fun rejectUpdate(f: File, msg: String) {
        f.delete()
        logUpdate("Rejected: $msg")
        toast("Update rejected: $msg")
    }

    private fun verifyAndInstall(f: File, rel: ReleaseInfo) {
        toast("Verifying SHA-256...")
        runBg({ runCatching { Mtz.sha256(f) } }) { r ->
            val actual = r.getOrNull()
            val expected = rel.sha256
            if (actual == null) {
                rejectUpdate(f, "could not read the downloaded file")
            } else if (expected == null) {
                rejectUpdate(f, "this release publishes no SHA-256, so the download cannot be verified")
            } else if (!actual.equals(expected, ignoreCase = true)) {
                rejectUpdate(f, "SHA-256 mismatch (file may be corrupted or tampered with)")
            } else {
                logUpdate("Downloaded ${rel.tag}, SHA-256 verified")
                verifyArchiveAndInstall(f, rel)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun verifyArchiveAndInstall(f: File, rel: ReleaseInfo) {
        val info = packageManager.getPackageArchiveInfo(f.absolutePath, 0)
        if (info == null) {
            rejectUpdate(f, "not a valid APK")
            return
        }
        if (info.packageName != packageName) {
            rejectUpdate(f, "package name mismatch (${info.packageName})")
            return
        }
        val newCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        val cur = packageManager.getPackageInfo(packageName, 0)
        val curCode = if (Build.VERSION.SDK_INT >= 28) cur.longVersionCode else cur.versionCode.toLong()
        if (newCode <= curCode) {
            rejectUpdate(f, "versionCode is not higher than the installed one")
            return
        }
        installApk(f, rel)
    }

    private fun installApk(f: File, rel: ReleaseInfo) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast("Allow ROTEXOS to install apps, then tap Download again.")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            logUpdate("Installer opened for ${rel.tag} (user must confirm)")
            startActivity(i) // Android's package installer asks the user to confirm; no silent install.
        } catch (e: Exception) {
            toast("Could not start the installer: ${e.message}")
        }
    }

    // ---------- activity results ----------

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_IMPORT_MTZ -> importMtz(uri)
            REQ_SAVE_EXPORT -> pendingExport?.let { copyFileToUri(it, uri) }
            REQ_SAVE_JSON -> writeTextToUri(pendingText.orEmpty(), uri)
            REQ_STUDIO_IMPORT -> importStudioProject(uri)
            REQ_INSPECT_MTZ -> inspectExternalMtz(uri)
            REQ_WALLPAPER_IMAGE -> chooseWallpaperTarget { which -> applyWallpaper({ decodeUriBitmap(uri) }, which) }
        }
    }
}
