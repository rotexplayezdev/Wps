package com.rotex.theme

import android.content.Context
import android.os.Build
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class TermLine(val kind: Int, val text: String) // 0 output, 1 error, 2 info

/**
 * Restricted command interpreter. Everything runs inside the app's private sandbox folder.
 * Every result comes from real file/network operations; nothing is simulated.
 * It is NOT a Linux shell: there are no processes, pipes, permissions or package managers.
 */
class Shell(ctx: Context) {
    val root: File = File(ctx.filesDir, "sandbox").apply { mkdirs() }.canonicalFile
    private val home: File = File(root, "home").apply { mkdirs() }.canonicalFile

    @Volatile
    var cwd: File = home
    val history = ArrayList<String>()

    private val unsupported = setOf(
        "sudo", "su", "apt", "apt-get", "pkg", "yum", "dnf", "ssh", "scp", "git", "python", "python3", "node", "npm",
        "gcc", "make", "vim", "nano", "vi", "top", "htop", "ps", "kill", "chmod", "chown", "chgrp", "mount", "umount",
        "ifconfig", "ip", "netstat", "ping", "wget", "systemctl", "service", "docker", "bash", "sh", "zsh", "ln",
        "tar", "zip", "unzip", "gzip", "sed", "awk", "sort", "uniq", "xargs", "tee", "man", "less", "more", "reboot"
    )

    fun virtual(f: File): String =
        if (f == root) "/" else "/" + f.relativeTo(root).path.replace(File.separatorChar, '/')

    fun prompt(): String {
        val c = cwd
        val where = if (c == home) "~" else if (c.path.startsWith(home.path + File.separator)) "~/" + c.relativeTo(home).path else virtual(c)
        return "mahin@rotexos:$where$ "
    }

    private fun denied(arg: String) = IOException("$arg: outside the sandbox - access denied")

    private fun resolve(arg: String): File? {
        val f = when {
            arg == "~" -> home
            arg.startsWith("~/") -> File(home, arg.substring(2))
            arg.startsWith("/") -> File(root, arg.substring(1))
            else -> File(cwd, arg)
        }
        val c = try {
            f.canonicalFile
        } catch (e: IOException) {
            return null
        }
        return if (c.path == root.path || c.path.startsWith(root.path + File.separator)) c else null
    }

    private fun need(arg: String): File = resolve(arg) ?: throw denied(arg)

    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = '\u0000'
        var has = false
        for (ch in s) {
            if (q != '\u0000') {
                if (ch == q) q = '\u0000' else sb.append(ch)
            } else if (ch == '"' || ch == '\'') {
                q = ch
                has = true
            } else if (ch.isWhitespace()) {
                if (sb.isNotEmpty() || has) {
                    out.add(sb.toString())
                    sb.setLength(0)
                    has = false
                }
            } else {
                sb.append(ch)
            }
        }
        if (q != '\u0000') throw IllegalArgumentException("unterminated quote")
        if (sb.isNotEmpty() || has) out.add(sb.toString())
        return out
    }

    private fun fmt(t: Long) = SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(t))

    private fun readText(f: File): String {
        if (!f.exists()) throw IOException("${f.name}: No such file")
        if (f.isDirectory) throw IOException("${f.name}: Is a directory")
        if (f.length() > 256 * 1024) throw IOException("${f.name}: file too large for this terminal (limit 256 KB)")
        return f.readText()
    }

    private fun size(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { size(it) } ?: 0L)

    fun exec(line: String): List<TermLine> {
        val out = ArrayList<TermLine>()
        val toks = try {
            tokenize(line)
        } catch (e: Exception) {
            return listOf(TermLine(1, "syntax error: ${e.message}"))
        }
        if (toks.isEmpty()) return out
        val cmd = toks[0]
        try {
            run(cmd, toks.drop(1), out)
        } catch (e: Exception) {
            out.add(TermLine(1, "$cmd: ${e.message ?: e.javaClass.simpleName}"))
        }
        return out
    }

    private fun run(cmd: String, args: List<String>, out: ArrayList<TermLine>) {
        val files = args.filter { !it.startsWith("-") }
        val flags = args.filter { it.startsWith("-") }.joinToString("")
        when (cmd) {
            "help" -> {
                out.add(TermLine(2, "ROTEXOS sandbox terminal - restricted, no root, not a full Linux shell."))
                out.add(TermLine(0, "Files:   ls [-la] [dir]  cd [dir]  pwd  cat f  head/tail [-n N] f  wc f  grep [-i] pat f"))
                out.add(TermLine(0, "         mkdir d  touch f  rm [-r] p  rmdir d  cp [-r] a b  mv a b  find [dir] [-name glob]  du"))
                out.add(TermLine(0, "         echo text [> f | >> f]  sha256sum f  base64 [-d] f"))
                out.add(TermLine(0, "System:  date  whoami  hostname  uname  env  sysinfo  uuid  epoch  history  clear  version"))
                out.add(TermLine(0, "Network: curl [-I] <http(s) url>   (GET/HEAD only)"))
                out.add(TermLine(2, "Anything else (sudo, apt, git, ssh, python, chmod, ps, ...) is not available here."))
            }
            "pwd" -> out.add(TermLine(0, virtual(cwd)))
            "whoami" -> out.add(TermLine(0, "mahin"))
            "hostname" -> out.add(TermLine(0, "rotexos"))
            "uname" -> out.add(TermLine(0, "ROTEXOS-sandbox (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}, ${Build.SUPPORTED_ABIS.firstOrNull() ?: "?"})"))
            "version" -> out.add(TermLine(0, "ROTEXOS ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})"))
            "date" -> out.add(TermLine(0, SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US).format(Date())))
            "epoch" -> out.add(TermLine(0, (System.currentTimeMillis() / 1000).toString()))
            "uuid" -> out.add(TermLine(0, UUID.randomUUID().toString()))
            "env" -> {
                out.add(TermLine(0, "USER=mahin"))
                out.add(TermLine(0, "HOME=/home"))
                out.add(TermLine(0, "PWD=${virtual(cwd)}"))
                out.add(TermLine(0, "SHELL=rotexos-sandbox"))
            }
            "sysinfo" -> {
                out.add(TermLine(0, "Device:  ${Build.MANUFACTURER} ${Build.MODEL}"))
                out.add(TermLine(0, "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"))
                out.add(TermLine(0, "CPU ABI: ${Build.SUPPORTED_ABIS.joinToString(", ")}"))
                val rt = Runtime.getRuntime()
                out.add(TermLine(0, "App heap: ${(rt.totalMemory() - rt.freeMemory()) / 1048576} MB used of ${rt.maxMemory() / 1048576} MB"))
                out.add(TermLine(0, "Sandbox: ${size(root) / 1024} KB used"))
            }
            "history" -> history.forEachIndexed { i, h -> out.add(TermLine(0, String.format(Locale.US, "%4d  %s", i + 1, h))) }
            "ls" -> {
                val target = if (files.isEmpty()) cwd else need(files[0])
                if (!target.exists()) throw IOException("cannot access '${files.firstOrNull()}': No such file or directory")
                val items = if (target.isDirectory) (target.listFiles()?.toList() ?: emptyList()) else listOf(target)
                val shown = items.filter { flags.contains('a') || !it.name.startsWith(".") }.sortedBy { it.name.lowercase() }
                if (flags.contains('l')) {
                    for (f in shown) {
                        out.add(TermLine(0, String.format(Locale.US, "%s %9d %s %s", if (f.isDirectory) "d" else "-", if (f.isDirectory) 0L else f.length(), fmt(f.lastModified()), f.name + if (f.isDirectory) "/" else "")))
                    }
                } else if (shown.isNotEmpty()) {
                    out.add(TermLine(0, shown.joinToString("  ") { it.name + if (it.isDirectory) "/" else "" }))
                }
            }
            "cd" -> {
                val t = if (files.isEmpty()) home else need(files[0])
                if (!t.exists()) throw IOException("${files[0]}: No such file or directory")
                if (!t.isDirectory) throw IOException("${files[0]}: Not a directory")
                cwd = t
            }
            "cat" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: cat <file>")
                for (a in files) readText(need(a)).lines().forEach { out.add(TermLine(0, it)) }
            }
            "head", "tail" -> {
                val nIdx = args.indexOf("-n")
                val n = if (nIdx >= 0 && nIdx + 1 < args.size) (args[nIdx + 1].toIntOrNull() ?: throw IllegalArgumentException("invalid line count")) else 10
                val name = args.filter { !it.startsWith("-") && it != (if (nIdx >= 0 && nIdx + 1 < args.size) args[nIdx + 1] else "") }.firstOrNull()
                    ?: throw IllegalArgumentException("usage: $cmd [-n N] <file>")
                val lines = readText(need(name)).lines()
                (if (cmd == "head") lines.take(n) else lines.takeLast(n)).forEach { out.add(TermLine(0, it)) }
            }
            "wc" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: wc <file>")
                for (a in files) {
                    val t = readText(need(a))
                    out.add(TermLine(0, "${t.lines().size} ${t.split(Regex("\\s+")).count { it.isNotEmpty() }} ${t.toByteArray().size} $a"))
                }
            }
            "grep" -> {
                if (files.size < 2) throw IllegalArgumentException("usage: grep [-i] [-n] <pattern> <file>")
                val ci = flags.contains('i')
                for (a in files.drop(1)) {
                    readText(need(a)).lines().forEachIndexed { i, l ->
                        if (l.contains(files[0], ci)) out.add(TermLine(0, (if (flags.contains('n')) "${i + 1}:" else "") + l))
                    }
                }
            }
            "mkdir" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: mkdir <dir>")
                for (a in files) {
                    val d = need(a)
                    if (d.exists() && !flags.contains('p')) throw IOException("cannot create '$a': File exists")
                    if (!d.exists() && !d.mkdirs()) throw IOException("cannot create '$a'")
                }
            }
            "touch" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: touch <file>")
                for (a in files) {
                    val f = need(a)
                    if (f.exists()) f.setLastModified(System.currentTimeMillis()) else f.createNewFile()
                }
            }
            "rm" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: rm [-r] <path>")
                for (a in files) {
                    val f = need(a)
                    if (f == root || f == home) throw IOException("refusing to remove $a")
                    if (!f.exists()) throw IOException("cannot remove '$a': No such file or directory")
                    if (f.isDirectory && !flags.contains('r')) throw IOException("cannot remove '$a': Is a directory (use -r)")
                    if (!f.deleteRecursively()) throw IOException("cannot remove '$a'")
                }
            }
            "rmdir" -> {
                for (a in files) {
                    val f = need(a)
                    if (!f.isDirectory) throw IOException("failed to remove '$a': Not a directory")
                    if (f == root || f == home) throw IOException("refusing to remove $a")
                    if (!f.delete()) throw IOException("failed to remove '$a': Directory not empty")
                }
            }
            "cp", "mv" -> {
                if (files.size != 2) throw IllegalArgumentException("usage: $cmd <source> <dest>")
                val src = need(files[0])
                var dst = need(files[1])
                if (!src.exists()) throw IOException("cannot stat '${files[0]}': No such file or directory")
                if (dst.isDirectory) dst = File(dst, src.name)
                if (src == root || src == home) throw IOException("refusing to touch ${files[0]}")
                if (src.isDirectory && cmd == "cp" && !flags.contains('r')) throw IOException("-r not specified; omitting directory '${files[0]}'")
                val checked = dst
                if (cmd == "cp") {
                    if (src.isDirectory) src.copyRecursively(checked, overwrite = true) else src.copyTo(checked, overwrite = true)
                } else if (!src.renameTo(checked)) {
                    throw IOException("cannot move '${files[0]}'")
                }
            }
            "echo" -> {
                val gt = args.indexOfFirst { it == ">" || it == ">>" }
                if (gt < 0) {
                    out.add(TermLine(0, args.joinToString(" ")))
                } else {
                    if (gt + 1 >= args.size) throw IllegalArgumentException("missing file after redirect")
                    val f = need(args[gt + 1])
                    val text = args.take(gt).joinToString(" ") + "\n"
                    if (args[gt] == ">>") f.appendText(text) else f.writeText(text)
                }
            }
            "sha256sum" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: sha256sum <file>")
                for (a in files) {
                    val f = need(a)
                    if (!f.isFile) throw IOException("$a: not a file")
                    out.add(TermLine(0, Mtz.sha256(f) + "  " + a))
                }
            }
            "base64" -> {
                if (files.isEmpty()) throw IllegalArgumentException("usage: base64 [-d] <file>")
                val f = need(files[0])
                if (flags.contains('d')) {
                    out.add(TermLine(0, String(android.util.Base64.decode(readText(f).trim(), android.util.Base64.DEFAULT), Charsets.UTF_8)))
                } else {
                    if (!f.isFile || f.length() > 256 * 1024) throw IOException("${files[0]}: unreadable or too large")
                    out.add(TermLine(0, android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP)))
                }
            }
            "du" -> out.add(TermLine(0, "${size(if (files.isEmpty()) cwd else need(files[0])) / 1024} KB"))
            "find" -> {
                val nameIdx = args.indexOf("-name")
                val glob = if (nameIdx >= 0 && nameIdx + 1 < args.size) args[nameIdx + 1] else null
                val startArg = args.firstOrNull { !it.startsWith("-") && it != glob }
                val start = if (startArg == null) cwd else need(startArg)
                val re = glob?.let { g ->
                    Regex(g.map { ch ->
                        when (ch) {
                            '*' -> ".*"
                            '?' -> "."
                            else -> Regex.escape(ch.toString())
                        }
                    }.joinToString(""))
                }
                var n = 0
                for (f in start.walkTopDown()) {
                    if (re == null || re.matches(f.name)) {
                        out.add(TermLine(0, virtual(f)))
                        if (++n >= 500) {
                            out.add(TermLine(2, "(stopped after 500 results)"))
                            break
                        }
                    }
                }
            }
            "curl" -> {
                val url = args.firstOrNull { !it.startsWith("-") } ?: throw IllegalArgumentException("usage: curl [-I] <http(s) url>")
                if (!url.startsWith("http://") && !url.startsWith("https://")) throw IllegalArgumentException("only http:// and https:// URLs")
                val head = args.contains("-I")
                val rb = Request.Builder().url(url)
                if (head) rb.head() else rb.get()
                Http.client.newCall(rb.build()).execute().use { r ->
                    out.add(TermLine(2, "HTTP ${r.code} ${r.message}"))
                    if (head) {
                        out.add(TermLine(0, r.headers.toString().trim()))
                    } else {
                        val body = r.peekBody(4096).string()
                        body.lines().forEach { out.add(TermLine(0, it)) }
                        out.add(TermLine(2, "(showing first 4 KB)"))
                    }
                }
            }
            else -> {
                if (unsupported.contains(cmd)) {
                    out.add(TermLine(1, "$cmd: not supported - the ROTEXOS terminal is a restricted sandbox, not a Linux shell."))
                } else {
                    out.add(TermLine(1, "$cmd: command not found. Type 'help'."))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- terminal page

private const val T_BG = 0xFF0A0E0C.toInt()
private const val T_PROMPT = 0xFF7CFF8A.toInt()
private const val T_CMD = 0xFFFFFFFF.toInt()
private const val T_OUT = 0xFFC9D1D9.toInt()
private const val T_ERR = 0xFFFF6B6B.toInt()
private const val T_INFO = 0xFF6CC7FF.toInt()

private fun MainActivity.termAppend(text: String, color: Int) {
    termText.append(text, ForegroundColorSpan(color), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    if (termText.length > 60000) termText.delete(0, termText.length - 40000)
}

// Independent of the Theme Gallery and of Pal: the terminal always uses its own dark palette.
internal fun MainActivity.terminalPage() {
    if (termText.isEmpty()) {
        termAppend("ROTEXOS Terminal ${BuildConfig.VERSION_NAME}\n", T_INFO)
        termAppend("Restricted sandbox inside the app's private folder. No root. Type 'help'.\n\n", T_OUT)
    }
    val wrap = LinearLayout(this)
    wrap.orientation = LinearLayout.VERTICAL
    wrap.background = rounded(T_BG, 18)
    wrap.setPadding(dp(12), dp(10), dp(12), dp(10))

    val title = LinearLayout(this)
    title.orientation = LinearLayout.HORIZONTAL
    title.gravity = Gravity.CENTER_VERTICAL
    for (col in intArrayOf(0xFFFF5F56.toInt(), 0xFFFFBD2E.toInt(), 0xFF27C93F.toInt())) {
        val d = View(this)
        d.background = rounded(col, 6)
        title.addView(d, LinearLayout.LayoutParams(dp(11), dp(11)).apply { rightMargin = dp(6) })
    }
    val tt = TextView(this)
    tt.text = "mahin@rotexos \u2014 sandbox"
    tt.setTextColor(0xFF8B949E.toInt())
    tt.textSize = 12f
    tt.typeface = android.graphics.Typeface.MONOSPACE
    tt.setPadding(dp(8), 0, 0, 0)
    title.addView(tt)
    wrap.addView(title, lp(bottom = 8))

    val out = TextView(this)
    out.typeface = android.graphics.Typeface.MONOSPACE
    out.textSize = 12.5f
    out.setTextColor(T_OUT)
    out.setTextIsSelectable(true)
    val sv = ScrollView(this)
    sv.addView(out)
    wrap.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

    fun refresh() {
        out.text = termText
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    val input = EditText(this)
    input.typeface = android.graphics.Typeface.MONOSPACE
    input.textSize = 14f
    input.setTextColor(T_CMD)
    input.setHintTextColor(0xFF6E7681.toInt())
    input.hint = "type a command (help)"
    input.setSingleLine(true)
    input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    input.imeOptions = EditorInfo.IME_ACTION_SEND
    input.background = rounded(0xFF161B22.toInt(), 12)
    input.setPadding(dp(12), dp(10), dp(12), dp(10))

    fun submit() {
        val line = input.text.toString()
        if (line.isBlank()) return
        input.setText("")
        shell.history.add(line)
        termHistoryPos = shell.history.size
        termAppend(shell.prompt(), T_PROMPT)
        termAppend(line + "\n", T_CMD)
        if (line.trim() == "clear") {
            termText.clear()
            refresh()
            return
        }
        refresh()
        termExec.execute {
            val res = shell.exec(line)
            runOnUiThread {
                for (l in res) {
                    termAppend(l.text + "\n", if (l.kind == 1) T_ERR else if (l.kind == 2) T_INFO else T_OUT)
                }
                refresh()
            }
        }
    }

    input.setOnEditorActionListener { _, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_SEND) {
            submit()
            true
        } else {
            false
        }
    }

    val bar = LinearLayout(this)
    bar.orientation = LinearLayout.HORIZONTAL
    fun small(t: String, f: () -> Unit): View {
        val b = btn(t, false, f)
        b.textSize = 12f
        b.setPadding(dp(8), dp(8), dp(8), dp(8))
        return b
    }
    val hist = shell.history
    for (v in listOf(
        small("\u25B2") {
            if (hist.isNotEmpty()) {
                termHistoryPos = (termHistoryPos - 1).coerceAtLeast(0)
                input.setText(hist[termHistoryPos])
                input.setSelection(input.text.length)
            }
        },
        small("\u25BC") {
            if (hist.isNotEmpty()) {
                termHistoryPos = (termHistoryPos + 1).coerceAtMost(hist.size)
                input.setText(if (termHistoryPos >= hist.size) "" else hist[termHistoryPos])
                input.setSelection(input.text.length)
            }
        },
        small("Clear") {
            termText.clear()
            refresh()
        },
        small("Copy") { copyText(termText.toString()) }
    )) {
        bar.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
    }
    wrap.addView(bar, lp(top = 8, bottom = 6))
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
    val send = btn("Run") { submit() }
    row.addView(send, lp(-2, -2).apply { leftMargin = dp(8) })
    wrap.addView(row)

    content.addView(wrap, LinearLayout.LayoutParams(-1, 0, 1f))
    refresh()
}
