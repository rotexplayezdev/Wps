package com.rotex.theme

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.LruCache
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin

enum class ThemeStyle { FLUID, LIQUID, OCEAN, TROPICAL, AURORA, CRYSTAL, MONO, SUNSET, NEON }

/**
 * A Theme Gallery entry. Purely descriptive + procedurally drawn previews.
 * It is NEVER applied to ROTEXOS's own UI (see Pal) and never claims system support.
 */
class ThemeDef(
    val id: String,
    val name: String,
    val tagline: String,
    val story: String,
    val style: ThemeStyle,
    val tags: List<String>,
    val accent: Int,
    val glassTint: Int,
    val glassAlpha: Int,
    val ink: Int,
    val palette: List<Int>,
    val widgets: List<String>,
    val concept: Boolean = false
)

object ThemeCatalog {
    private fun c(h: String): Int = parseHex(h)!!

    val all: List<ThemeDef> = listOf(
        ThemeDef(
            "midnight_fluid", "Midnight Fluid", "Deep navy marble, white minimal icons",
            "Black-to-navy fluid wallpaper with soft indigo ribbons, white line icons and light typography.",
            ThemeStyle.FLUID, listOf("Dark", "Minimal"), c("#6C7BFF"), c("#FFFFFF"), 30, c("#F2F4FF"),
            listOf(c("#050816"), c("#0B1240"), c("#2A34B8"), c("#6C7BFF"), c("#F2F4FF")),
            listOf("Calendar + clock", "Stats chart", "Notes list", "Large clock")
        ),
        ThemeDef(
            "liquid_glass", "Liquid Glass", "Frosted cards over glowing color blobs",
            "Translucent frosted-glass widgets with soft highlights floating above a liquid gradient background.",
            ThemeStyle.LIQUID, listOf("Glass", "Dark"), c("#FF7AD9"), c("#FFFFFF"), 48, c("#FFFFFF"),
            listOf(c("#120533"), c("#3813C2"), c("#FF6FD8"), c("#00E0FF"), c("#FFFFFF")),
            listOf("Frosted clock", "Music card", "Weather glass", "Photo tile")
        ),
        ThemeDef(
            "ocean_glass", "Ocean Glass", "Dark sea, cyan light, glass widgets",
            "Deep ocean wallpaper with light rays and waves, cyan accents and calm glass widgets.",
            ThemeStyle.OCEAN, listOf("Dark", "Glass", "Nature"), c("#35D0FF"), c("#9CD8FF"), 38, c("#E8F7FF"),
            listOf(c("#02122B"), c("#0A3A7A"), c("#1E7FD6"), c("#35D0FF"), c("#E8F7FF")),
            listOf("Calendar glass", "Marine photo tile", "Weather", "Now playing")
        ),
        ThemeDef(
            "tropical_frost", "Tropical Frost", "Palms, sea and frosted white glass",
            "Neutral grey-blue beach scene with palm trees, sand and white frosted-glass icon tiles.",
            ThemeStyle.TROPICAL, listOf("Glass", "Nature"), c("#FFFFFF"), c("#FFFFFF"), 70, c("#FFFFFF"),
            listOf(c("#C4D0D2"), c("#86A0A4"), c("#DDD6C8"), c("#2A332F"), c("#FFFFFF")),
            listOf("Date + clock", "Photo mosaic", "Beach tile", "Surf photo")
        ),
        ThemeDef(
            "aurora_glass", "Aurora Glass", "Northern-light gradients under glass",
            "Green, violet and cyan aurora lighting with translucent cards.",
            ThemeStyle.AURORA, listOf("Glass", "Dark"), c("#00F5A0"), c("#FFFFFF"), 36, c("#FFFFFF"),
            listOf(c("#030816"), c("#9B5CFF"), c("#00D4FF"), c("#00F5A0"), c("#FFFFFF")),
            listOf("Glass clock", "Mood card", "Weather", "Photo tile")
        ),
        ThemeDef(
            "crystal_dark", "Crystal Dark", "Premium black glass with facets",
            "Near-black faceted wallpaper with subtle reflections and restrained glass cards.",
            ThemeStyle.CRYSTAL, listOf("Dark", "Glass"), c("#C9D1FF"), c("#FFFFFF"), 20, c("#F4F6FF"),
            listOf(c("#05050A"), c("#15151F"), c("#3B3F66"), c("#C9D1FF"), c("#FFFFFF")),
            listOf("Slim clock", "Stats", "Calendar", "Notes")
        ),
        ThemeDef(
            "minimal_mono", "Minimal Monochrome", "Clean black and white",
            "Bright monochrome wallpaper with thin circles, black line icons and quiet widgets.",
            ThemeStyle.MONO, listOf("Minimal"), c("#2B2B2B"), c("#FFFFFF"), 120, c("#111111"),
            listOf(c("#FFFFFF"), c("#E4E4E6"), c("#9A9A9A"), c("#2B2B2B"), c("#000000")),
            listOf("Date", "Weather", "To-do", "Large clock")
        ),
        ThemeDef(
            "sunset_neon", "Sunset Neon", "Retro synthwave sunset",
            "Concept: purple-to-orange sunset with a retro grid and neon pink accents.",
            ThemeStyle.SUNSET, listOf("Neon", "Dark"), c("#FF2E93"), c("#FFFFFF"), 34, c("#FFFFFF"),
            listOf(c("#1B0B3B"), c("#FF2E93"), c("#FF9A3C"), c("#FFE259"), c("#FFFFFF")),
            listOf("Neon clock", "Music card", "Stats", "Photo tile"), true
        ),
        ThemeDef(
            "rotex_neon", "Rotex Neon", "ROTEX brand: neon green on black",
            "Concept in the ROTEX brand colors: black, neon green and silver.",
            ThemeStyle.NEON, listOf("Neon", "Dark"), c("#00FF66"), c("#C0C7CC"), 26, c("#F2FFF6"),
            listOf(c("#040806"), c("#0D3B1E"), c("#00FF66"), c("#C0C7CC"), c("#FFFFFF")),
            listOf("Brand clock", "Stats", "Dev notes", "Terminal tile"), true
        )
    )

    fun find(id: String): ThemeDef? = all.firstOrNull { it.id == id }
}

/** Procedural wallpaper art. Everything is drawn with Canvas; nothing is copied from the reference images. */
object ThemeArt {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    /** Small cached bitmap for previews. Callers must NOT recycle it. */
    fun bitmap(t: ThemeDef, w: Int, h: Int): Bitmap {
        val key = "${t.id}:$w:$h"
        val hit = cache.get(key)
        if (hit != null) return hit
        val b = render(t, w, h)
        cache.put(key, b)
        return b
    }

    /** Fresh bitmap (caller owns it). */
    fun render(t: ThemeDef, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(b), w.toFloat(), h.toFloat(), t)
        return b
    }

    fun draw(c: Canvas, w: Float, h: Float, t: ThemeDef) {
        when (t.style) {
            ThemeStyle.FLUID -> fluid(c, w, h)
            ThemeStyle.LIQUID -> liquid(c, w, h)
            ThemeStyle.OCEAN -> ocean(c, w, h)
            ThemeStyle.TROPICAL -> tropical(c, w, h)
            ThemeStyle.AURORA -> aurora(c, w, h)
            ThemeStyle.CRYSTAL -> crystal(c, w, h)
            ThemeStyle.MONO -> mono(c, w, h)
            ThemeStyle.SUNSET -> sunset(c, w, h)
            ThemeStyle.NEON -> neon(c, w, h)
        }
    }

    private fun lin(x0: Float, y0: Float, x1: Float, y1: Float, vararg cols: Int): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(x0, y0, x1, y1, cols, null, Shader.TileMode.CLAMP)
        return p
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(cx, cy, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
    }

    private fun stroke(width: Float, color: Int): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = width
        p.color = color
        return p
    }

    private fun fluid(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, w, h, 0xFF03040C.toInt(), 0xFF0B1240.toInt(), 0xFF020308.toInt()))
        val path = Path()
        for (i in 0 until 16) {
            val y = h * (-0.05f + (i / 16f) * 1.1f)
            path.reset()
            path.moveTo(-w * 0.1f, y)
            path.cubicTo(
                w * 0.25f, y - h * 0.10f * sin(i * 1.7f),
                w * 0.65f, y + h * 0.14f * cos(i * 1.3f),
                w * 1.1f, y + h * 0.06f * sin(i * 0.9f)
            )
            val p = stroke(w * (0.015f + 0.02f * ((i * 7) % 5) / 5f), Color.argb(40 + (i * 37) % 90, 70 + (i * 11) % 60, 80 + (i * 17) % 60, 230))
            c.drawPath(path, p)
        }
    }

    private fun liquid(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, w, h, 0xFF120533.toInt(), 0xFF2A0F6B.toInt(), 0xFF05102E.toInt()))
        blob(c, w * 0.2f, h * 0.2f, w * 0.8f, 0xCCFF4FD8.toInt())
        blob(c, w * 0.9f, h * 0.45f, w * 0.9f, 0xCC4C2BFF.toInt())
        blob(c, w * 0.3f, h * 0.8f, w * 0.9f, 0xCC00D5FF.toInt())
        blob(c, w * 0.75f, h * 0.97f, w * 0.6f, 0xAAFFB86B.toInt())
    }

    private fun ocean(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, 0f, h, 0xFF02122B.toInt(), 0xFF0A3A7A.toInt(), 0xFF03122E.toInt()))
        val ray = lin(0f, 0f, 0f, h * 0.8f, 0x44FFFFFF, 0x00FFFFFF)
        val path = Path()
        for (i in 0 until 6) {
            val x = w * (0.05f + 0.17f * i)
            path.reset()
            path.moveTo(x, 0f)
            path.lineTo(x + w * 0.16f, 0f)
            path.lineTo(x + w * 0.02f, h * 0.8f)
            path.lineTo(x - w * 0.22f, h * 0.8f)
            path.close()
            c.drawPath(path, ray)
        }
        for (k in 0 until 3) {
            val y = h * (0.72f + 0.07f * k)
            val crest = Path()
            crest.moveTo(0f, y)
            for (s in 1..24) crest.lineTo(w * s / 24f, y + sin(s * 0.8f + k) * h * 0.015f)
            val fill = Path(crest)
            fill.lineTo(w, h)
            fill.lineTo(0f, h)
            fill.close()
            val fp = Paint(Paint.ANTI_ALIAS_FLAG)
            fp.color = Color.argb(150 + 30 * k, 11, 47, 102)
            c.drawPath(fill, fp)
            c.drawPath(crest, stroke(w * 0.006f, 0x66FFFFFF))
        }
    }

    private fun palm(c: Canvas, bx: Float, by: Float, ph: Float, lean: Float) {
        val tx = bx + lean * ph
        val ty = by - ph
        val trunk = Path()
        trunk.moveTo(bx, by)
        trunk.quadTo(bx + lean * ph * 0.5f, by - ph * 0.5f, tx, ty)
        c.drawPath(trunk, stroke(ph * 0.035f, 0xFF2A332F.toInt()))
        for (k in 0 until 8) {
            val a = Math.toRadians((-200 + k * 26).toDouble()).toFloat()
            val len = ph * 0.38f
            val ex = tx + cos(a) * len
            val ey = ty + sin(a) * len + len * 0.35f
            val cx = tx + cos(a) * len * 0.5f
            val cy = ty + sin(a) * len * 0.5f - len * 0.25f
            val leaf = Path()
            leaf.moveTo(tx, ty)
            leaf.quadTo(cx, cy, ex, ey)
            c.drawPath(leaf, stroke(ph * 0.03f, 0xFF27312C.toInt()))
        }
    }

    private fun tropical(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h * 0.55f, lin(0f, 0f, 0f, h * 0.55f, 0xFFC4D0D2.toInt(), 0xFF9FB2B6.toInt()))
        c.drawRect(0f, h * 0.55f, w, h * 0.78f, lin(0f, h * 0.55f, 0f, h * 0.78f, 0xFF86A0A4.toInt(), 0xFF6C888C.toInt()))
        c.drawRect(0f, h * 0.78f, w, h, lin(0f, h * 0.78f, 0f, h, 0xFFDDD6C8.toInt(), 0xFFC9C0AE.toInt()))
        for (i in 0 until 5) {
            val y = h * (0.6f + 0.035f * i)
            val p = Path()
            p.moveTo(0f, y)
            for (s in 1..16) p.lineTo(w * s / 16f, y + sin(s * 0.9f + i) * h * 0.006f)
            c.drawPath(p, stroke(w * 0.004f, 0x55FFFFFF))
        }
        palm(c, w * 0.18f, h * 0.97f, h * 0.62f, -0.15f)
        palm(c, w * 0.92f, h * 1.0f, h * 0.5f, 0.2f)
        palm(c, w * 0.55f, h * 1.0f, h * 0.33f, 0.1f)
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, 0f, h, 0x22FFFFFF, 0x00FFFFFF))
    }

    private fun aurora(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, 0f, h, 0xFF030816.toInt(), 0xFF08122E.toInt()))
        blob(c, w * 0.2f, h * 0.25f, w * 0.9f, 0xAA00F5A0.toInt())
        blob(c, w * 0.85f, h * 0.3f, w * 0.8f, 0x999B5CFF.toInt())
        blob(c, w * 0.5f, h * 0.6f, w * 1.0f, 0x8800D4FF.toInt())
        blob(c, w * 0.2f, h * 0.92f, w * 0.8f, 0x99FF5CC8.toInt())
        val band = Path()
        band.moveTo(-w * 0.1f, h * 0.35f)
        band.cubicTo(w * 0.3f, h * 0.1f, w * 0.6f, h * 0.55f, w * 1.1f, h * 0.25f)
        c.drawPath(band, stroke(w * 0.05f, 0x28FFFFFF))
    }

    private fun crystal(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, w, h, 0xFF05050A.toInt(), 0xFF15151F.toInt(), 0xFF08080E.toInt()))
        val rnd = Random(11)
        val path = Path()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 26) {
            path.reset()
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            path.moveTo(x, y)
            path.lineTo(x + (rnd.nextFloat() - 0.4f) * w * 0.7f, y + (rnd.nextFloat() - 0.4f) * h * 0.3f)
            path.lineTo(x + (rnd.nextFloat() - 0.6f) * w * 0.7f, y + rnd.nextFloat() * h * 0.3f)
            path.close()
            fill.color = Color.argb(4 + rnd.nextInt(14), 255, 255, 255)
            c.drawPath(path, fill)
            c.drawPath(path, stroke(1.2f, 0x18FFFFFF))
        }
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, w * 0.8f, h * 0.5f, 0x30FFFFFF, 0x00FFFFFF))
    }

    private fun mono(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, 0f, h, 0xFFFFFFFF.toInt(), 0xFFE4E4E6.toInt()))
        for (i in 1..8) c.drawCircle(w * 0.78f, h * 0.28f, w * 0.12f * i, stroke(w * 0.004f, 0x22000000))
        c.drawLine(0f, h * 0.62f, w, h * 0.62f, stroke(w * 0.003f, 0x22000000))
    }

    private fun sunset(c: Canvas, w: Float, h: Float) {
        val horizon = h * 0.62f
        c.drawRect(0f, 0f, w, horizon, lin(0f, 0f, 0f, horizon, 0xFF1B0B3B.toInt(), 0xFFB0227A.toInt(), 0xFFFF9A3C.toInt()))
        c.drawRect(0f, horizon, w, h, lin(0f, horizon, 0f, h, 0xFF14052B.toInt(), 0xFF0A0218.toInt()))
        blob(c, w * 0.5f, horizon, w * 0.7f, 0x66FF2E93.toInt())
        val sun = lin(0f, horizon - w * 0.3f, 0f, horizon, 0xFFFFE259.toInt(), 0xFFFF2E93.toInt())
        c.drawCircle(w * 0.5f, horizon - w * 0.02f, w * 0.28f, sun)
        c.drawRect(0f, horizon, w, h, lin(0f, horizon, 0f, h, 0xFF14052B.toInt(), 0xFF0A0218.toInt()))
        val g = stroke(w * 0.004f, 0x88FF2E93.toInt())
        for (i in -6..6) c.drawLine(w / 2 + i * w * 0.35f, h, w / 2 + i * w * 0.04f, horizon, g)
        for (k in 1..6) {
            val f = k / 6f
            val y = horizon + (h - horizon) * f * f
            c.drawLine(0f, y, w, y, g)
        }
    }

    private fun neon(c: Canvas, w: Float, h: Float) {
        c.drawRect(0f, 0f, w, h, lin(0f, 0f, 0f, h, 0xFF040806.toInt(), 0xFF07120B.toInt()))
        blob(c, w * 0.5f, h * 0.35f, w * 0.9f, 0x8800FF66.toInt())
        for (i in 0 until 9) {
            val x = -w * 0.2f + i * w * 0.18f
            c.drawLine(x, h, x + w * 0.5f, 0f, stroke(w * 0.003f, 0x3300FF66))
        }
        c.drawCircle(w * 0.5f, h * 0.35f, w * 0.32f, stroke(w * 0.006f, 0x55C0C7CC))
        c.drawCircle(w * 0.5f, h * 0.35f, w * 0.24f, stroke(w * 0.003f, 0x33C0C7CC))
    }
}
