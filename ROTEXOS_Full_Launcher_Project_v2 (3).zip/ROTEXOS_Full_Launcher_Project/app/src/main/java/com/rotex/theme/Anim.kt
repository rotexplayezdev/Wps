package com.rotex.theme

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout

/** Cheap press feedback (scale). No continuous animation, so no battery cost. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

/** One-shot staggered entrance used when a page opens. */
fun View.enterAnim(index: Int) {
    alpha = 0f
    translationY = 28f * resources.displayMetrics.density
    animate().alpha(1f).translationY(0f).setStartDelay(index * 45L).setDuration(280)
        .setInterpolator(DecelerateInterpolator()).start()
}

/** Three pulsing dots. Animators run only while the view is attached to the window. */
class DotsLoader(context: Context) : LinearLayout(context) {
    private val anims = ArrayList<ObjectAnimator>()
    private val dots = ArrayList<View>()

    init {
        gravity = Gravity.CENTER
        val size = (10 * resources.displayMetrics.density).toInt()
        val gap = (5 * resources.displayMetrics.density).toInt()
        setPadding(0, gap * 3, 0, gap * 3)
        for (i in 0 until 3) {
            val d = View(context)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Pal.accent)
            d.background = g
            d.alpha = 0.25f
            val lp = LayoutParams(size, size)
            lp.setMargins(gap, 0, gap, 0)
            addView(d, lp)
            dots.add(d)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anims.clear()
        dots.forEachIndexed { i, d ->
            val a = ObjectAnimator.ofFloat(d, "alpha", 0.25f, 1f)
            a.duration = 600
            a.repeatMode = android.animation.ValueAnimator.REVERSE
            a.repeatCount = android.animation.ValueAnimator.INFINITE
            a.startDelay = i * 160L
            a.start()
            anims.add(a)
        }
    }

    override fun onDetachedFromWindow() {
        anims.forEach { it.cancel() }
        anims.clear()
        super.onDetachedFromWindow()
    }
}
