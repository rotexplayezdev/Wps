package com.rotex.theme

import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min

// The Theme Gallery is fully independent: it draws its own previews and never touches Pal (the app UI).

internal fun MainActivity.favThemes(): MutableSet<String> =
    (prefs.getString("fav_themes", "") ?: "").split(',').filter { it.isNotEmpty() }.toMutableSet()

internal fun MainActivity.toggleFav(id: String): Boolean {
    val f = favThemes()
    val now = if (f.contains(id)) {
        f.remove(id)
        false
    } else {
        f.add(id)
        true
    }
    prefs.edit().putString("fav_themes", f.joinToString(",")).apply()
    return now
}

private val GALLERY_CATEGORIES = listOf("All", "Dark", "Glass", "Nature", "Minimal", "Neon", "Favorites")

internal fun MainActivity.galleryPage() {
    addCard(
        "Independent theme previews",
        "These previews are drawings inside ROTEXOS. Opening a theme never changes this app's own look, Android, MIUI or HyperOS."
    )
    val search = EditText(this)
    search.hint = "Search themes"
    search.setSingleLine(true)
    search.setText(galleryQuery)
    search.setTextColor(Pal.ink)
    search.setHintTextColor(Pal.sub)
    search.background = rounded(Pal.field, 14)
    search.setPadding(dp(14), dp(12), dp(14), dp(12))
    content.addView(search, lp(bottom = 10))

    val chipScroll = HorizontalScrollView(this)
    chipScroll.isHorizontalScrollBarEnabled = false
    val chips = LinearLayout(this)
    chips.orientation = LinearLayout.HORIZONTAL
    chipScroll.addView(chips)
    content.addView(chipScroll, lp(bottom = 12))

    val grid = LinearLayout(this)
    grid.orientation = LinearLayout.VERTICAL
    content.addView(grid)

    var animateTiles = true

    fun render() {
        chips.removeAllViews()
        for (cat in GALLERY_CATEGORIES) {
            val sel = cat == galleryCategory
            val t = label(cat, 13, if (sel) 0xFFFFFFFF.toInt() else Pal.ink, sel)
            t.background = rounded(if (sel) Pal.accent else Pal.card, 18)
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener {
                galleryCategory = cat
                render()
            }
            t.pressable()
            chips.addView(t, lp(-2, -2).apply { rightMargin = dp(8) })
        }
        grid.removeAllViews()
        val q = galleryQuery.trim().lowercase()
        val favs = favThemes()
        val list = ThemeCatalog.all.filter { t ->
            val inCat = when (galleryCategory) {
                "All" -> true
                "Favorites" -> favs.contains(t.id)
                else -> t.tags.contains(galleryCategory)
            }
            val inQuery = q.isEmpty() || t.name.lowercase().contains(q) || t.tagline.lowercase().contains(q) ||
                t.tags.any { it.lowercase().contains(q) }
            inCat && inQuery
        }
        if (list.isEmpty()) {
            grid.addView(
                emptyState(
                    if (galleryCategory == "Favorites") "\u2665" else "?",
                    if (galleryCategory == "Favorites") "No favorites yet" else "No themes found",
                    if (galleryCategory == "Favorites") "Tap the heart on a theme to keep it here." else "Try another search or category."
                )
            )
            return
        }
        var idx = 0
        for (pair in list.chunked(2)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 2) {
                val t = pair.getOrNull(i)
                val cell = LinearLayout(this)
                cell.setPadding(dp(5), dp(5), dp(5), dp(5))
                if (t != null) {
                    val tile = themeTile(t)
                    cell.addView(tile, LinearLayout.LayoutParams(-1, -2))
                    if (animateTiles) tile.enterAnim(idx++)
                }
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            grid.addView(row)
        }
    }

    search.addTextChangedListener(watcher {
        galleryQuery = it
        render()
    })
    render()
    animateTiles = false
}

private fun MainActivity.themeTile(t: ThemeDef): View {
    val c = card()
    c.setPadding(dp(8), dp(8), dp(8), dp(10))
    c.addView(PhonePreviewView(this, t, 0), LinearLayout.LayoutParams(-1, -2))
    val name = label(t.name, 14, Pal.ink, true)
    name.setPadding(dp(4), dp(8), dp(4), 0)
    name.maxLines = 1
    c.addView(name)
    val tag = label(if (t.concept) "Concept \u2022 " + t.tags.joinToString(", ") else t.tags.joinToString(", "), 11, Pal.sub)
    tag.setPadding(dp(4), dp(2), dp(4), 0)
    tag.maxLines = 1
    c.addView(tag)
    val fav = label(if (favThemes().contains(t.id)) "\u2665 Favorite" else "\u2661 Favorite", 12, Pal.accent, true)
    fav.setPadding(dp(4), dp(8), dp(4), 0)
    fav.setOnClickListener {
        val on = toggleFav(t.id)
        fav.text = if (on) "\u2665 Favorite" else "\u2661 Favorite"
        if (galleryCategory == "Favorites") showPage("Gallery")
    }
    c.addView(fav)
    c.setOnClickListener {
        selectedThemeId = t.id
        showPage("GalleryDetail")
    }
    c.pressable()
    return c
}

internal fun MainActivity.galleryDetailPage() {
    val t = ThemeCatalog.find(selectedThemeId)
    if (t == null) {
        content.addView(emptyState("?", "Theme not found", "Go back to the gallery and pick another theme."))
        return
    }
    val strip = HorizontalScrollView(this)
    strip.isHorizontalScrollBarEnabled = false
    val inner = LinearLayout(this)
    inner.orientation = LinearLayout.HORIZONTAL
    val captions = listOf("Home", "Widgets", "App grid", "Custom page", "Lock (concept)")
    for (p in 0 until 5) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(PhonePreviewView(this, t, p), LinearLayout.LayoutParams(dp(190), -2))
        val cap = label(captions[p], 12, Pal.sub)
        cap.setPadding(0, dp(6), 0, 0)
        col.addView(cap)
        inner.addView(col, lp(-2, -2).apply { rightMargin = dp(14) })
    }
    strip.addView(inner)
    content.addView(strip, lp(bottom = 12))

    val head = card()
    head.addView(label(t.name, 20, Pal.ink, true))
    head.addView(label(t.tagline, 14, Pal.sub).apply { setPadding(0, dp(4), 0, dp(8)) })
    head.addView(label(t.story, 13, Pal.ink))
    head.addView(label((if (t.concept) "Concept theme \u2022 " else "") + t.tags.joinToString(" \u2022 "), 12, Pal.sub).apply { setPadding(0, dp(8), 0, 0) })
    content.addView(head, lp(bottom = 12))
    head.enterAnim(0)

    val actions = card()
    actions.addView(label("Actions", 17, Pal.ink, true))
    val fav = btn(if (favThemes().contains(t.id)) "\u2665 Remove from favorites" else "\u2661 Add to favorites", false) {
        toggleFav(t.id)
        showPage("GalleryDetail")
    }
    actions.addView(fav, lp(top = 10, bottom = 8))
    actions.addView(btn("Export theme pack (.mtz)") { exportThemePack(t) }, lp(bottom = 8))
    actions.addView(btn("Set wallpaper only", false) {
        val dm = realMetrics()
        val w = min(dm.widthPixels, dm.heightPixels)
        val h = max(dm.widthPixels, dm.heightPixels)
        chooseWallpaperTarget { which -> applyWallpaper({ ThemeArt.render(t, w, h) }, which) }
    }, lp(bottom = 8))
    actions.addView(btn("Copy palette", false) { copyText(t.palette.joinToString("\n") { hex(it) }) })
    content.addView(actions, lp(bottom = 12))

    val honest = card()
    honest.addView(label("Preview vs export vs real device support", 16, Pal.ink, true))
    honest.addView(
        label(
            "PREVIEW: what you see above is drawn inside ROTEXOS. Icons, widgets and lock screen are mockups; glass is simulated.\n\n" +
                "EXPORTED PACK: a wallpaper-only .mtz file. Whether Xiaomi Themes accepts or applies it depends on your MIUI/HyperOS version. ROTEXOS does not bypass Xiaomi's checks.\n\n" +
                "REAL DEVICE ACTION: the only thing ROTEXOS can genuinely set on the phone is the wallpaper (home/lock) via Android's WallpaperManager. A normal app cannot replace the lock-screen UI, icon pack or system widgets.",
            12, Pal.sub
        ).apply { setPadding(0, dp(8), 0, 0) }
    )
    content.addView(honest, lp(bottom = 12))

    val pal = card()
    pal.addView(label("Palette", 17, Pal.ink, true))
    val prow = LinearLayout(this)
    prow.orientation = LinearLayout.HORIZONTAL
    for (col in t.palette) {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        val sw = View(this)
        sw.background = rounded(col, 12)
        cell.addView(sw, LinearLayout.LayoutParams(-1, dp(44)))
        cell.addView(label(hex(col), 10, Pal.sub).apply { setPadding(0, dp(4), 0, 0) })
        cell.setOnClickListener { copyText(hex(col)) }
        prow.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
    }
    pal.addView(prow, lp(top = 8))
    pal.addView(label("Icon preview", 14, Pal.ink, true).apply { setPadding(0, dp(14), 0, dp(6)) })
    pal.addView(IconStripView(this, t))
    content.addView(pal, lp(bottom = 12))

    val wid = card()
    wid.addView(label("Widget layouts", 17, Pal.ink, true))
    for (w in t.widgets) wid.addView(label("\u2022 $w", 13, Pal.sub).apply { setPadding(0, dp(6), 0, 0) })
    wid.addView(label("Four coordinated pages: Home, Widgets, App grid and a Custom page.", 12, Pal.sub).apply { setPadding(0, dp(10), 0, 0) })
    content.addView(wid, lp(bottom = 12))
}

internal fun MainActivity.exportThemePack(t: ThemeDef) {
    val dm = realMetrics()
    val w = min(min(dm.widthPixels, dm.heightPixels), 1440)
    val h = min(max(dm.widthPixels, dm.heightPixels), 3200)
    val author = studio.author
    toast("Building theme pack...")
    runBg({
        runCatching {
            val bmp = ThemeArt.render(t, w, h)
            try {
                val dest: File = ThemeStore.newFile(this, t.name)
                val json = JSONObject()
                json.put("format", "rotexos-theme-pack")
                json.put("version", 1)
                json.put("themeId", t.id)
                json.put("name", t.name)
                json.put("style", t.style.name.lowercase())
                json.put("concept", t.concept)
                json.put("palette", JSONArray(t.palette.map { hex(it) }))
                json.put("note", "Wallpaper-only pack. Icons, widgets and lock screen in the gallery are previews.")
                Mtz.buildFromBitmap(bmp, t.name, author, json.toString(2), dest)
                dest
            } finally {
                bmp.recycle()
            }
        }
    }) { r ->
        r.onSuccess { showExportDone(it) }.onFailure { toast("Export failed: ${it.message ?: "unknown error"}") }
    }
}
