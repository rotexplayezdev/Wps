package com.rotex.theme

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.util.regex.Pattern

class JsonError(message: String, val pos: Int) : Exception(message)
class JNum(val text: String)

/** Small strict JSON parser (no comments, no trailing commas) with formatter, minifier, highlighter and YAML dump. */
object Json {
    private val NUM = Pattern.compile("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?")

    fun parse(s: String): Any? {
        val p = Parser(s)
        p.ws()
        val v = p.value(0)
        p.ws()
        if (p.i < s.length) throw JsonError("Unexpected data after the JSON value", p.i)
        return v
    }

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(depth: Int): Any? {
            if (depth > 200) throw JsonError("Nesting is too deep", i)
            ws()
            if (i >= s.length) throw JsonError("Unexpected end of input", i)
            val c = s[i]
            return when {
                c == '{' -> obj(depth)
                c == '[' -> arr(depth)
                c == '"' -> str()
                c == 't' -> lit("true", true)
                c == 'f' -> lit("false", false)
                c == 'n' -> lit("null", null)
                c == '-' || (c in '0'..'9') -> num()
                else -> throw JsonError("Unexpected character '$c'", i)
            }
        }

        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw JsonError("Invalid literal", i)
            i += w.length
            return v
        }

        fun num(): Any? {
            val m = NUM.matcher(s)
            m.region(i, s.length)
            if (!m.lookingAt()) throw JsonError("Invalid number", i)
            i = m.end()
            return JNum(m.group())
        }

        fun str(): String {
            val start = i
            i++
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw JsonError("Unterminated string", start)
                val c = s[i++]
                if (c == '"') return sb.toString()
                if (c == '\\') {
                    if (i >= s.length) throw JsonError("Bad escape sequence", i)
                    val e = s[i++]
                    when (e) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> {
                            if (i + 4 > s.length) throw JsonError("Bad \\u escape", i)
                            val code = s.substring(i, i + 4).toIntOrNull(16) ?: throw JsonError("Bad \\u escape", i)
                            sb.append(code.toChar())
                            i += 4
                        }
                        else -> throw JsonError("Invalid escape '\\$e'", i - 1)
                    }
                } else if (c < ' ') {
                    throw JsonError("Control character inside string", i - 1)
                } else {
                    sb.append(c)
                }
            }
        }

        fun obj(depth: Int): Any? {
            i++
            val m = LinkedHashMap<String, Any?>()
            ws()
            if (i < s.length && s[i] == '}') {
                i++
                return m
            }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') throw JsonError("Expected a string key", i)
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') throw JsonError("Expected ':' after key", i)
                i++
                m[k] = value(depth + 1)
                ws()
                if (i >= s.length) throw JsonError("Unexpected end of input", i)
                if (s[i] == ',') {
                    i++
                    continue
                }
                if (s[i] == '}') {
                    i++
                    return m
                }
                throw JsonError("Expected ',' or '}'", i)
            }
        }

        fun arr(depth: Int): Any? {
            i++
            val l = ArrayList<Any?>()
            ws()
            if (i < s.length && s[i] == ']') {
                i++
                return l
            }
            while (true) {
                l.add(value(depth + 1))
                ws()
                if (i >= s.length) throw JsonError("Unexpected end of input", i)
                if (s[i] == ',') {
                    i++
                    continue
                }
                if (s[i] == ']') {
                    i++
                    return l
                }
                throw JsonError("Expected ',' or ']'", i)
            }
        }
    }

    fun pretty(v: Any?): String {
        val sb = StringBuilder()
        write(v, sb, true, 0)
        return sb.toString()
    }

    fun minify(v: Any?): String {
        val sb = StringBuilder()
        write(v, sb, false, 0)
        return sb.toString()
    }

    private fun indent(sb: StringBuilder, level: Int) {
        for (i in 0 until level) sb.append("  ")
    }

    private fun quote(s: String, sb: StringBuilder) {
        sb.append('"')
        for (ch in s) {
            when {
                ch == '"' -> sb.append("\\\"")
                ch == '\\' -> sb.append("\\\\")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch == '\t' -> sb.append("\\t")
                ch < ' ' -> sb.append(String.format("\\u%04x", ch.code))
                else -> sb.append(ch)
            }
        }
        sb.append('"')
    }

    private fun write(v: Any?, sb: StringBuilder, pretty: Boolean, level: Int) {
        if (v == null) {
            sb.append("null")
        } else if (v is Boolean) {
            sb.append(v.toString())
        } else if (v is JNum) {
            sb.append(v.text)
        } else if (v is String) {
            quote(v, sb)
        } else if (v is Map<*, *>) {
            if (v.isEmpty()) {
                sb.append("{}")
                return
            }
            sb.append('{')
            var first = true
            for ((k, x) in v) {
                if (!first) sb.append(',')
                first = false
                if (pretty) {
                    sb.append('\n')
                    indent(sb, level + 1)
                }
                quote(k.toString(), sb)
                sb.append(if (pretty) ": " else ":")
                write(x, sb, pretty, level + 1)
            }
            if (pretty) {
                sb.append('\n')
                indent(sb, level)
            }
            sb.append('}')
        } else if (v is List<*>) {
            if (v.isEmpty()) {
                sb.append("[]")
                return
            }
            sb.append('[')
            var first = true
            for (x in v) {
                if (!first) sb.append(',')
                first = false
                if (pretty) {
                    sb.append('\n')
                    indent(sb, level + 1)
                }
                write(x, sb, pretty, level + 1)
            }
            if (pretty) {
                sb.append('\n')
                indent(sb, level)
            }
            sb.append(']')
        } else {
            sb.append(v.toString())
        }
    }

    // ---- YAML dump ----
    private val RESERVED = setOf("true", "false", "null", "yes", "no", "on", "off", "~")
    private val PLAIN = Regex("[A-Za-z_][A-Za-z0-9_ ./-]*")

    private fun ystr(s: String): String {
        if (s.isNotEmpty() && PLAIN.matches(s) && !s.endsWith(" ") && !RESERVED.contains(s.lowercase())) return s
        val sb = StringBuilder()
        quote(s, sb)
        return sb.toString()
    }

    private fun isEmptyColl(x: Any?) = (x is Map<*, *> && x.isEmpty()) || (x is List<*> && x.isEmpty())
    private fun isScalar(x: Any?) = x == null || x is Boolean || x is JNum || x is String

    private fun yinline(x: Any?): String = when {
        x == null -> "null"
        x is Boolean -> x.toString()
        x is JNum -> x.text
        x is String -> ystr(x)
        x is Map<*, *> -> "{}"
        else -> "[]"
    }

    private fun y(v: Any?, sb: StringBuilder, level: Int) {
        val pad = "  ".repeat(level)
        if (v is Map<*, *>) {
            for ((k, x) in v) {
                sb.append(pad).append(ystr(k.toString())).append(':')
                if (isScalar(x) || isEmptyColl(x)) {
                    sb.append(' ').append(yinline(x)).append('\n')
                } else {
                    sb.append('\n')
                    y(x, sb, level + 1)
                }
            }
        } else if (v is List<*>) {
            for (x in v) {
                if (isScalar(x) || isEmptyColl(x)) {
                    sb.append(pad).append("- ").append(yinline(x)).append('\n')
                } else {
                    sb.append(pad).append("-\n")
                    y(x, sb, level + 1)
                }
            }
        } else {
            sb.append(pad).append(yinline(v)).append('\n')
        }
    }

    fun toYaml(v: Any?): String {
        if (isEmptyColl(v)) return yinline(v) + "\n"
        val sb = StringBuilder()
        y(v, sb, 0)
        return sb.toString()
    }

    // ---- syntax highlighting (input must be valid JSON text) ----
    private fun span(sb: SpannableStringBuilder, a: Int, b: Int, color: Int) {
        sb.setSpan(ForegroundColorSpan(color), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun highlight(text: String): CharSequence {
        if (text.length > 150_000) return text
        val dark = Pal.dark
        val cKey = if (dark) 0xFF7CC4FF.toInt() else 0xFF0B5FB0.toInt()
        val cStr = if (dark) 0xFFA5E075.toInt() else 0xFF2E7D32.toInt()
        val cNum = if (dark) 0xFFFFB86C.toInt() else 0xFFB35900.toInt()
        val cKw = if (dark) 0xFFFF79C6.toInt() else 0xFFAD1A72.toInt()
        val cPun = if (dark) 0xFF8B93B5.toInt() else 0xFF666C84.toInt()
        val sb = SpannableStringBuilder(text)
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '"') {
                var j = i + 1
                while (j < text.length && text[j] != '"') {
                    if (text[j] == '\\') j++
                    j++
                }
                j = minOf(j + 1, text.length)
                var k = j
                while (k < text.length && text[k].isWhitespace()) k++
                val isKey = k < text.length && text[k] == ':'
                span(sb, i, j, if (isKey) cKey else cStr)
                i = j
            } else if (c == '-' || c in '0'..'9') {
                var j = i + 1
                while (j < text.length && (text[j] in '0'..'9' || text[j] == '.' || text[j] == 'e' || text[j] == 'E' || text[j] == '+' || text[j] == '-')) j++
                span(sb, i, j, cNum)
                i = j
            } else if (text.startsWith("true", i) || text.startsWith("null", i)) {
                span(sb, i, i + 4, cKw)
                i += 4
            } else if (text.startsWith("false", i)) {
                span(sb, i, i + 5, cKw)
                i += 5
            } else if (c == '{' || c == '}' || c == '[' || c == ']' || c == ',' || c == ':') {
                span(sb, i, i + 1, cPun)
                i++
            } else {
                i++
            }
        }
        return sb
    }
}

/** Basic YAML checker/formatter for a common subset. NOT a full YAML parser. */
object YamlLite {
    private fun quotesBalanced(s: String): Boolean {
        var single = false
        var dbl = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (dbl && c == '\\') {
                i += 2
                continue
            }
            if (!single && c == '"') dbl = !dbl
            else if (!dbl && c == '\'') single = !single
            else if (!single && !dbl && c == '#' && (i == 0 || s[i - 1] == ' ')) break
            i++
        }
        return !single && !dbl
    }

    fun check(text: String): List<String> {
        val errs = ArrayList<String>()
        val stack = ArrayList<Int>()
        stack.add(0)
        var prevIndent = 0
        var prevOpens = false
        var blockIndent = -1
        val keys = HashMap<Int, HashSet<String>>()
        val lines = text.replace("\r", "").split("\n")
        for ((n, raw) in lines.withIndex()) {
            val ln = n + 1
            val lead = raw.takeWhile { it == ' ' || it == '\t' }
            if (lead.contains('\t')) {
                errs.add("Line $ln: tab used for indentation (YAML requires spaces)")
                continue
            }
            val t = raw.trim()
            if (t.isEmpty() || t.startsWith("#") || t == "---" || t == "...") continue
            val indent = lead.length
            if (blockIndent >= 0) {
                if (indent > blockIndent) continue
                blockIndent = -1
            }
            if (!quotesBalanced(t)) errs.add("Line $ln: unbalanced quote")
            if (indent > prevIndent && !prevOpens) errs.add("Line $ln: unexpected indentation")
            if (indent < prevIndent && !stack.contains(indent)) errs.add("Line $ln: indentation does not match any outer level")
            while (stack.isNotEmpty() && stack.last() > indent) stack.removeAt(stack.size - 1)
            if (stack.isEmpty() || stack.last() < indent) stack.add(indent)
            val deeper = keys.keys.filter { it > indent }
            for (d in deeper) keys.remove(d)

            val isItem = t == "-" || t.startsWith("- ")
            val content = if (isItem) t.removePrefix("-").trim() else t
            val keyIndent = if (isItem) indent + 2 else indent
            if (isItem) keys.remove(keyIndent)
            val colon = findKeyColon(content)
            if (colon >= 0) {
                val key = content.substring(0, colon).trim().trim('"', '\'')
                val set = keys.getOrPut(keyIndent) { HashSet() }
                if (!set.add(key)) errs.add("Line $ln: duplicate key '$key'")
            } else if (!isItem && !content.startsWith("{") && !content.startsWith("[")) {
                errs.add("Line $ln: expected 'key: value' or '- item'")
            }
            val rest = if (colon >= 0) content.substring(colon + 1).trim() else content
            prevOpens = (colon >= 0 && rest.isEmpty()) || t == "-" || (isItem && colon >= 0 && rest.isEmpty())
            if (rest == "|" || rest == ">" || rest.startsWith("|") || rest.startsWith(">")) {
                if (colon >= 0) blockIndent = indent
            }
            prevIndent = indent
        }
        return errs
    }

    private fun findKeyColon(s: String): Int {
        var single = false
        var dbl = false
        for (i in s.indices) {
            val c = s[i]
            if (c == '"' && !single) dbl = !dbl
            else if (c == '\'' && !dbl) single = !single
            else if (c == ':' && !single && !dbl && (i == s.length - 1 || s[i + 1] == ' ')) return i
        }
        return -1
    }

    /** Light formatting: normalizes line endings, trims trailing spaces, collapses blank runs. */
    fun format(text: String): String {
        val out = ArrayList<String>()
        var blank = 0
        for (l in text.replace("\r", "").split("\n")) {
            val line = l.trimEnd()
            if (line.isEmpty()) {
                blank++
                if (blank > 1) continue
            } else {
                blank = 0
            }
            out.add(line)
        }
        return out.joinToString("\n").trim() + "\n"
    }
}
