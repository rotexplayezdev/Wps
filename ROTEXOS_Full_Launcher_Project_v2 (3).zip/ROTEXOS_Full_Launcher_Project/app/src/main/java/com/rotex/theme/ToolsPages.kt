package com.rotex.theme

import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Random
import java.util.regex.Pattern
import java.util.regex.PatternSyntaxException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class ApiResult(
    val code: Int = 0,
    val message: String = "",
    val ms: Long = 0,
    val size: Int = 0,
    val headers: String = "",
    val body: String = "",
    val error: String? = null
)

class ApiState {
    var method = "GET"
    var url = "https://httpbin.org/get"
    var headers = "Accept: application/json"
    var body = ""
    var last: ApiResult? = null
    var showHeaders = false
}

// ---------------------------------------------------------------- shared UI helpers

internal fun MainActivity.editor(hint: String, lines: Int, mono: Boolean = true): EditText {
    val et = EditText(this)
    et.hint = hint
    et.setTextColor(Pal.ink)
    et.setHintTextColor(Pal.sub)
    et.background = rounded(Pal.field, 14)
    et.setPadding(dp(12), dp(10), dp(12), dp(10))
    et.minLines = lines
    et.gravity = Gravity.TOP or Gravity.START
    et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    if (mono) {
        et.typeface = Typeface.MONOSPACE
        et.textSize = 13f
    }
    return et
}

internal fun MainActivity.outputView(): TextView {
    val tv = TextView(this)
    tv.typeface = Typeface.MONOSPACE
    tv.textSize = 12.5f
    tv.setTextColor(Pal.ink)
    tv.setTextIsSelectable(true)
    tv.background = rounded(Pal.field, 14)
    tv.setPadding(dp(12), dp(10), dp(12), dp(10))
    tv.minLines = 3
    return tv
}

internal fun MainActivity.rowOf(vararg views: View): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    for (v in views) {
        val p = LinearLayout.LayoutParams(0, -2, 1f)
        p.setMargins(dp(3), 0, dp(3), 0)
        r.addView(v, p)
    }
    return r
}

// ---------------------------------------------------------------- tools hub

internal fun MainActivity.toolsPage() {
    addCard("API Tester", "GET, POST, PUT, PATCH and DELETE with headers, body, JSON viewer, status and timing.", "Open API Tester") { showPage("ToolApi") }
    addCard("JSON & YAML Studio", "Strict JSON format, minify and validate with error positions, syntax colors, JSON to YAML, basic YAML check.", "Open JSON & YAML") { showPage("ToolJson") }
    addCard("Regex Playground", "Live matches, groups, flags, timeout protection and ready-made examples.", "Open Regex Playground") { showPage("ToolRegex") }
    addCard("Encoder & Hash Toolkit", "Base64, URL, Hex, SHA-256 and text utilities.", "Open Encoder & Hash") { showPage("ToolEncode") }
    addCard("Color & Gradient Studio", "HEX / RGB / HSL, picker, palettes and gradient generator with CSS and Android XML.", "Open Color Studio") { showPage("ToolColor") }
    content.addView(label("System tools", 17, Pal.ink, true), lp(top = 8, bottom = 8))
    addCard("App Inspector", "Package, versions, SDK levels, signing SHA-256 and permissions. Also: long-press any app.", "Pick an app") {
        loadApps { apps ->
            val labels = apps.map { it.label }.toTypedArray()
            dialog().setTitle("Inspect which app?").setItems(labels) { _, i -> inspectApp(apps[i].pkg) }.show()
        }
    }
    addCard("MTZ Inspector", "Validate an .mtz without importing it: structure, metadata, file list, SHA-256.", "Choose .mtz") { pickFile(REQ_INSPECT_MTZ) }
    addCard("Gradient code export", "Current Studio gradient as Android XML, Compose, CSS, colors.xml or JSON.", "Export gradient") { showCodeExport() }
    addCard("Device Profile", "Screen, density, refresh rate, Android / MIUI / HyperOS version and ideal wallpaper size.", "Show profile") {
        showText("Device profile", DevTools.deviceProfile(realMetrics(), refreshRate()))
    }
    addCard("Intent Lab", "Fire a URI or launch a package; shortcuts to Developer options and Xiaomi Themes.", "Open Intent Lab") { showIntentLab() }
}

// ---------------------------------------------------------------- API tester

private fun doRequest(method: String, url: String, headerText: String, bodyText: String): ApiResult {
    val rb = Request.Builder().url(url)
    var hasContentType = false
    for (line in headerText.lines()) {
        val t = line.trim()
        if (t.isEmpty()) continue
        val i = t.indexOf(':')
        if (i <= 0) throw IllegalArgumentException("Bad header line (use Name: value): $t")
        val k = t.substring(0, i).trim()
        if (k.equals("Content-Type", true)) hasContentType = true
        rb.header(k, t.substring(i + 1).trim())
    }
    val sendsBody = method == "POST" || method == "PUT" || method == "PATCH" || (method == "DELETE" && bodyText.isNotEmpty())
    val body: RequestBody? = if (sendsBody) {
        val ct = if (hasContentType) null else "application/json; charset=utf-8".toMediaTypeOrNull()
        bodyText.toRequestBody(ct)
    } else null
    rb.method(method, body)
    val t0 = System.nanoTime()
    return Http.client.newCall(rb.build()).execute().use { resp ->
        val text = resp.peekBody(2L * 1024 * 1024).string()
        val ms = (System.nanoTime() - t0) / 1_000_000
        ApiResult(resp.code, resp.message, ms, text.toByteArray().size, resp.headers.toString().trim(), text)
    }
}

internal fun MainActivity.apiToolPage() {
    val c = card()
    val methods = LinearLayout(this)
    methods.orientation = LinearLayout.HORIZONTAL
    for (m in listOf("GET", "POST", "PUT", "PATCH", "DELETE")) {
        val b = btn(m, api.method == m) {
            api.method = m
            showPage("ToolApi")
        }
        b.textSize = 11f
        b.setPadding(dp(2), dp(10), dp(2), dp(10))
        val p = LinearLayout.LayoutParams(0, -2, 1f)
        p.setMargins(dp(2), 0, dp(2), 0)
        methods.addView(b, p)
    }
    c.addView(methods, lp(bottom = 10))
    val url = editor("https://api.example.com/items", 1)
    url.setText(api.url)
    url.addTextChangedListener(watcher { api.url = it })
    c.addView(url, lp(bottom = 8))
    val hdr = editor("Headers, one per line\nAuthorization: Bearer ...", 3)
    hdr.setText(api.headers)
    hdr.addTextChangedListener(watcher { api.headers = it })
    c.addView(hdr, lp(bottom = 8))
    val body = editor("Request body (JSON)", 5)
    body.setText(api.body)
    body.addTextChangedListener(watcher { api.body = it })
    c.addView(body, lp(bottom = 8))
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    c.addView(btn("Send request") {
        val u = api.url.trim()
        if (!(u.startsWith("http://") || u.startsWith("https://"))) {
            toast("URL must start with http:// or https://")
        } else {
            box.removeAllViews()
            box.addView(DotsLoader(this))
            val m = api.method
            val h = api.headers
            val b = api.body
            runBg({ runCatching { doRequest(m, u, h, b) } }) { r ->
                api.last = r.getOrElse { e -> ApiResult(error = e.message ?: e.javaClass.simpleName) }
                renderApi(box)
            }
        }
    }, lp(bottom = 4))
    content.addView(c, lp(bottom = 12))
    val res = card()
    res.addView(label("Response", 17, Pal.ink, true))
    res.addView(box, lp(top = 8))
    content.addView(res, lp(bottom = 12))
    if (api.last != null) renderApi(box) else box.addView(label("Nothing sent yet. Cleartext http:// is allowed here so you can test local servers.", 12, Pal.sub))
    content.addView(label("Note: requests run on your device and go straight to the URL you enter.", 11, Pal.sub))
}

private fun MainActivity.renderApi(box: LinearLayout) {
    box.removeAllViews()
    val r = api.last ?: return
    val err = r.error
    if (err != null) {
        box.addView(label("Request failed", 15, Pal.danger, true))
        box.addView(label(err, 13, Pal.ink).apply { setPadding(0, dp(4), 0, 0) })
        return
    }
    val col = if (r.code in 200..299) 0xFF2E9E5B.toInt() else if (r.code in 300..399) 0xFFE0A100.toInt() else Pal.danger
    box.addView(label("${r.code} ${r.message}  \u2022  ${r.ms} ms  \u2022  ${r.size} bytes", 14, col, true))
    val tabs = rowOf(
        btn("Body", !api.showHeaders) {
            api.showHeaders = false
            renderApi(box)
        },
        btn("Headers", api.showHeaders) {
            api.showHeaders = true
            renderApi(box)
        }
    )
    box.addView(tabs, lp(top = 8, bottom = 8))
    val out = outputView()
    if (api.showHeaders) {
        out.text = r.headers
    } else {
        val shown = r.body.take(200_000)
        out.text = try {
            Json.highlight(Json.pretty(Json.parse(shown)))
        } catch (_: Exception) {
            shown
        }
    }
    box.addView(out)
    box.addView(btn("Copy ${if (api.showHeaders) "headers" else "body"}", false) {
        copyText(if (api.showHeaders) r.headers else r.body)
    }, lp(top = 8))
}

// ---------------------------------------------------------------- JSON & YAML

private fun lineCol(text: String, pos: Int): Pair<Int, Int> {
    var line = 1
    var col = 1
    for (i in 0 until min(pos, text.length)) {
        if (text[i] == '\n') {
            line++
            col = 1
        } else {
            col++
        }
    }
    return line to col
}

internal fun MainActivity.jsonToolPage() {
    val yaml = toolState["json_mode"] == "yaml"
    val c = card()
    c.addView(rowOf(
        btn("JSON", !yaml) {
            toolState["json_mode"] = "json"
            showPage("ToolJson")
        },
        btn("YAML (basic)", yaml) {
            toolState["json_mode"] = "yaml"
            showPage("ToolJson")
        }
    ), lp(bottom = 10))
    val input = editor(if (yaml) "Paste YAML" else "Paste JSON", 9)
    input.setText(toolState["json_in"] ?: "")
    input.addTextChangedListener(watcher { toolState["json_in"] = it })
    c.addView(input, lp(bottom = 8))
    val status = label("", 13, Pal.sub)
    val out = outputView()
    var lastOut = ""

    fun ok(msg: String, text: CharSequence, plain: String) {
        status.text = msg
        status.setTextColor(0xFF2E9E5B.toInt())
        out.text = text
        lastOut = plain
    }

    fun bad(msg: String) {
        status.text = msg
        status.setTextColor(Pal.danger)
        out.text = ""
        lastOut = ""
    }

    fun runJson(action: String) {
        val txt = input.text.toString()
        try {
            val v = Json.parse(txt)
            when (action) {
                "format" -> {
                    val p = Json.pretty(v)
                    ok("Valid JSON - formatted", Json.highlight(p), p)
                }
                "min" -> {
                    val p = Json.minify(v)
                    ok("Valid JSON - minified (${p.length} chars)", Json.highlight(p), p)
                }
                "yaml" -> {
                    val p = Json.toYaml(v)
                    ok("Converted to YAML", p, p)
                }
                else -> ok("Valid JSON (${txt.length} chars)", "", "")
            }
        } catch (e: JsonError) {
            val lc = lineCol(txt, e.pos)
            bad("Invalid JSON - line ${lc.first}, column ${lc.second}: ${e.message}")
        }
    }

    fun runYaml(action: String) {
        val txt = input.text.toString()
        val errs = YamlLite.check(txt)
        if (errs.isNotEmpty()) {
            bad("YAML problems (${errs.size}):\n" + errs.take(8).joinToString("\n"))
            return
        }
        if (action == "format") {
            val p = YamlLite.format(txt)
            ok("No problems found by the basic checker - formatted", p, p)
        } else {
            ok("No problems found by the basic checker", "", "")
        }
    }

    if (!yaml) {
        c.addView(rowOf(btn("Format") { runJson("format") }, btn("Minify", false) { runJson("min") }), lp(bottom = 6))
        c.addView(rowOf(btn("Validate", false) { runJson("validate") }, btn("To YAML", false) { runJson("yaml") }), lp(bottom = 6))
    } else {
        c.addView(rowOf(btn("Check") { runYaml("check") }, btn("Format", false) { runYaml("format") }), lp(bottom = 6))
        c.addView(label("YAML support is a basic subset checker (indentation, tabs, quotes, duplicate keys), not a full YAML parser.", 11, Pal.sub), lp(bottom = 6))
    }
    c.addView(status, lp(top = 4, bottom = 6))
    c.addView(out)
    c.addView(rowOf(
        btn("Copy", false) { if (lastOut.isEmpty()) toast("Nothing to copy yet") else copyText(lastOut) },
        btn("Save file", false) {
            if (lastOut.isEmpty()) {
                toast("Nothing to save yet")
            } else {
                pendingText = lastOut
                createDoc(REQ_SAVE_JSON, if (yaml) "output.yaml" else "output.json", "text/plain")
            }
        },
        btn("Clear", false) {
            toolState["json_in"] = ""
            showPage("ToolJson")
        }
    ), lp(top = 8))
    content.addView(c, lp(bottom = 12))
}

// ---------------------------------------------------------------- Regex

class RegexTimeout : RuntimeException("Regex took too long (possible catastrophic backtracking)")

class LimitedChars(private val s: CharSequence, private val deadline: Long) : CharSequence {
    override val length: Int get() = s.length
    override fun get(index: Int): Char {
        if (System.currentTimeMillis() > deadline) throw RegexTimeout()
        return s[index]
    }
    override fun subSequence(startIndex: Int, endIndex: Int): CharSequence = LimitedChars(s.subSequence(startIndex, endIndex), deadline)
    override fun toString(): String = s.toString()
}

private val REGEX_EXAMPLES = listOf(
    Triple("Email", """[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}""", "Contact dev@rotexos.app or mahin@example.com today."),
    Triple("URL", """https?://[^\s]+""", "Docs: https://developer.android.com/ and http://localhost:8080/api"),
    Triple("ISO date", """\b\d{4}-\d{2}-\d{2}\b""", "Released 2026-11-24, patched 2026-12-01."),
    Triple("Hex color", """#(?:[0-9a-fA-F]{3}){1,2}\b""", "Colors: #5265FF, #fff and #00ff66"),
    Triple("IPv4", """\b(?:\d{1,3}\.){3}\d{1,3}\b""", "Servers 192.168.0.12 and 10.0.0.1"),
    Triple("Version", """\bv?\d+\.\d+\.\d+\b""", "Upgrade from v1.1.0 to 1.2.0"),
    Triple("Capitalized words", """\b[A-Z][a-z]+\b""", "Made by Mahin in Bangladesh")
)

internal fun MainActivity.regexToolPage() {
    val c = card()
    val pat = editor("Pattern, e.g. \\b\\w+\\b", 2)
    pat.setText(toolState["rx_pat"] ?: "")
    val txt = editor("Test string", 6)
    txt.setText(toolState["rx_txt"] ?: "")
    val ci = CheckBox(this)
    ci.text = "i"
    ci.setTextColor(Pal.ink)
    val ml = CheckBox(this)
    ml.text = "m"
    ml.setTextColor(Pal.ink)
    val dot = CheckBox(this)
    dot.text = "s"
    dot.setTextColor(Pal.ink)
    val result = LinearLayout(this)
    result.orientation = LinearLayout.VERTICAL

    fun runRegex() {
        toolState["rx_pat"] = pat.text.toString()
        toolState["rx_txt"] = txt.text.toString()
        result.removeAllViews()
        val p = pat.text.toString()
        val t = txt.text.toString()
        if (p.isEmpty()) {
            result.addView(label("Type a pattern to see matches.", 13, Pal.sub))
            return
        }
        var f = 0
        if (ci.isChecked) f = f or Pattern.CASE_INSENSITIVE
        if (ml.isChecked) f = f or Pattern.MULTILINE
        if (dot.isChecked) f = f or Pattern.DOTALL
        val re = try {
            Pattern.compile(p, f)
        } catch (e: PatternSyntaxException) {
            result.addView(label("Pattern error: ${e.description}" + (if (e.index >= 0) " (at ${e.index})" else ""), 13, Pal.danger))
            return
        }
        val sb = SpannableStringBuilder(t)
        val list = StringBuilder()
        var count = 0
        try {
            val m = re.matcher(LimitedChars(t, System.currentTimeMillis() + 1500))
            while (m.find()) {
                count++
                if (count <= 200) {
                    if (m.end() > m.start()) {
                        sb.setSpan(
                            BackgroundColorSpan(if (count % 2 == 0) 0x66FFB020 else 0x6600C2FF),
                            m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                    }
                    list.append("#").append(count).append(" [").append(m.start()).append("-").append(m.end()).append("] ")
                        .append(m.group().replace("\n", "\\n")).append('\n')
                    for (g in 1..m.groupCount()) list.append("    group ").append(g).append(": ").append(m.group(g) ?: "(none)").append('\n')
                }
                if (count >= 5000) break
            }
        } catch (e: RegexTimeout) {
            result.addView(label(e.message ?: "Timeout", 13, Pal.danger))
            return
        }
        result.addView(label(if (count == 0) "No matches" else "$count match${if (count == 1) "" else "es"}", 14, if (count == 0) Pal.sub else 0xFF2E9E5B.toInt(), true))
        val hl = outputView()
        hl.text = sb
        result.addView(hl, lp(top = 8, bottom = 8))
        if (list.isNotEmpty()) {
            val lv = outputView()
            lv.text = list.toString()
            result.addView(lv)
        }
    }

    pat.addTextChangedListener(watcher { runRegex() })
    txt.addTextChangedListener(watcher { runRegex() })
    val cl = CompoundButtonListener { runRegex() }
    ci.setOnCheckedChangeListener(cl)
    ml.setOnCheckedChangeListener(cl)
    dot.setOnCheckedChangeListener(cl)

    c.addView(pat, lp(bottom = 6))
    c.addView(rowOf(ci, ml, dot), lp(bottom = 6))
    c.addView(txt, lp(bottom = 8))
    c.addView(btn("Examples", false) {
        dialog().setTitle("Regex examples").setItems(REGEX_EXAMPLES.map { it.first }.toTypedArray()) { _, i ->
            pat.setText(REGEX_EXAMPLES[i].second)
            txt.setText(REGEX_EXAMPLES[i].third)
        }.show()
    }, lp(bottom = 8))
    c.addView(result)
    content.addView(c, lp(bottom = 12))
    runRegex()
}

private class CompoundButtonListener(val f: () -> Unit) : android.widget.CompoundButton.OnCheckedChangeListener {
    override fun onCheckedChanged(b: android.widget.CompoundButton?, checked: Boolean) {
        f()
    }
}

// ---------------------------------------------------------------- Encoder & hash

private fun hexOf(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

internal fun MainActivity.encodeToolPage() {
    val c = card()
    val input = editor("Input text", 5)
    input.setText(toolState["enc_in"] ?: "")
    input.addTextChangedListener(watcher { toolState["enc_in"] = it })
    c.addView(input, lp(bottom = 8))
    val status = label("", 12, Pal.sub)
    val out = outputView()

    fun op(name: String, f: (String) -> String): View = btn(name, false) {
        try {
            out.text = f(input.text.toString())
            status.text = ""
        } catch (e: Exception) {
            out.text = ""
            status.text = "$name failed: ${e.message ?: "invalid input"}"
            status.setTextColor(Pal.danger)
        }
    }

    c.addView(rowOf(
        op("Base64 encode") { Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) },
        op("Base64 decode") { String(Base64.decode(it.trim(), Base64.DEFAULT), Charsets.UTF_8) }
    ), lp(bottom = 6))
    c.addView(rowOf(
        op("URL encode") { URLEncoder.encode(it, "UTF-8") },
        op("URL decode") { URLDecoder.decode(it, "UTF-8") }
    ), lp(bottom = 6))
    c.addView(rowOf(
        op("SHA-256") { hexOf(MessageDigest.getInstance("SHA-256").digest(it.toByteArray(Charsets.UTF_8))) },
        op("Hex encode") { hexOf(it.toByteArray(Charsets.UTF_8)) }
    ), lp(bottom = 6))
    c.addView(rowOf(
        op("Hex decode") { s ->
            val t = s.filter { !it.isWhitespace() }
            if (t.length % 2 != 0) throw IllegalArgumentException("odd number of hex digits")
            val bytes = ByteArray(t.length / 2) { i ->
                (t.substring(i * 2, i * 2 + 2).toIntOrNull(16) ?: throw IllegalArgumentException("not hex")).toByte()
            }
            String(bytes, Charsets.UTF_8)
        },
        op("Count") { "${it.length} chars, ${it.toByteArray(Charsets.UTF_8).size} bytes, ${it.lines().size} lines" }
    ), lp(bottom = 6))
    c.addView(rowOf(
        op("UPPERCASE") { it.uppercase() },
        op("lowercase") { it.lowercase() },
        op("Reverse") { it.reversed() }
    ), lp(bottom = 6))
    c.addView(status, lp(top = 4, bottom = 6))
    c.addView(out)
    c.addView(rowOf(
        btn("Copy result", false) { if (out.text.isEmpty()) toast("Nothing to copy yet") else copyText(out.text.toString()) },
        btn("Use as input", false) {
            input.setText(out.text.toString())
            out.text = ""
        }
    ), lp(top = 8))
    content.addView(c, lp(bottom = 12))
}

// ---------------------------------------------------------------- Color & gradient

object ColorMath {
    fun toHsl(c: Int): FloatArray {
        val r = Color.red(c) / 255f
        val g = Color.green(c) / 255f
        val b = Color.blue(c) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val l = (mx + mn) / 2f
        val d = mx - mn
        var h = 0f
        var s = 0f
        if (d > 0f) {
            s = d / (1f - abs(2f * l - 1f))
            h = if (mx == r) ((g - b) / d) % 6f else if (mx == g) (b - r) / d + 2f else (r - g) / d + 4f
            h *= 60f
            if (h < 0f) h += 360f
        }
        return floatArrayOf(h, s, l)
    }

    fun fromHsl(h: Float, s: Float, l: Float): Int {
        val c = (1f - abs(2f * l - 1f)) * s
        val hp = (((h % 360f) + 360f) % 360f) / 60f
        val x = c * (1f - abs(hp % 2f - 1f))
        val rgb = when (hp.toInt()) {
            0 -> floatArrayOf(c, x, 0f)
            1 -> floatArrayOf(x, c, 0f)
            2 -> floatArrayOf(0f, c, x)
            3 -> floatArrayOf(0f, x, c)
            4 -> floatArrayOf(x, 0f, c)
            else -> floatArrayOf(c, 0f, x)
        }
        val m = l - c / 2f
        return Color.rgb(
            ((rgb[0] + m) * 255f).roundToInt().coerceIn(0, 255),
            ((rgb[1] + m) * 255f).roundToInt().coerceIn(0, 255),
            ((rgb[2] + m) * 255f).roundToInt().coerceIn(0, 255)
        )
    }
}

private fun MainActivity.savePalettesList(arr: JSONArray) {
    prefs.edit().putString("palettes", arr.toString()).apply()
}

private fun MainActivity.palettesList(): JSONArray = try {
    JSONArray(prefs.getString("palettes", "[]") ?: "[]")
} catch (_: Exception) {
    JSONArray()
}

internal fun MainActivity.persistWorkPalette() {
    prefs.edit().putString("work_palette", workColors.joinToString(",") { hex(it) }).apply()
}

internal fun MainActivity.colorToolPage() {
    var busy = false
    val c = card()
    val swatch = View(this)
    c.addView(swatch, LinearLayout.LayoutParams(-1, dp(84)))
    val hexEt = editor("#RRGGBB", 1)
    val rgbEt = editor("r, g, b", 1)
    val hslEt = editor("h, s%, l%", 1)
    c.addView(label("HEX", 12, Pal.sub).apply { setPadding(0, dp(10), 0, dp(2)) })
    c.addView(hexEt)
    c.addView(label("RGB", 12, Pal.sub).apply { setPadding(0, dp(8), 0, dp(2)) })
    c.addView(rgbEt)
    c.addView(label("HSL", 12, Pal.sub).apply { setPadding(0, dp(8), 0, dp(2)) })
    c.addView(hslEt)
    val hSb = SeekBar(this)
    hSb.max = 360
    val sSb = SeekBar(this)
    sSb.max = 100
    val vSb = SeekBar(this)
    vSb.max = 100
    c.addView(label("Picker: hue / saturation / value", 12, Pal.sub).apply { setPadding(0, dp(10), 0, 0) })
    c.addView(hSb)
    c.addView(sSb)
    c.addView(vSb)

    fun setColorTo(col: Int, source: String) {
        colorValue = col
        busy = true
        swatch.background = rounded(col, 16)
        if (source != "hex") hexEt.setText(hex(col))
        if (source != "rgb") rgbEt.setText("${Color.red(col)}, ${Color.green(col)}, ${Color.blue(col)}")
        if (source != "hsl") {
            val h = ColorMath.toHsl(col)
            hslEt.setText("${h[0].roundToInt()}, ${(h[1] * 100).roundToInt()}%, ${(h[2] * 100).roundToInt()}%")
        }
        if (source != "hsv") {
            val hv = FloatArray(3)
            Color.colorToHSV(col, hv)
            hSb.progress = hv[0].toInt()
            sSb.progress = (hv[1] * 100).toInt()
            vSb.progress = (hv[2] * 100).toInt()
        }
        busy = false
    }

    hexEt.addTextChangedListener(watcher { s ->
        if (!busy) parseHex(s)?.let { setColorTo(it, "hex") }
    })
    rgbEt.addTextChangedListener(watcher { s ->
        if (!busy) {
            val n = Regex("\\d+").findAll(s).mapNotNull { it.value.toIntOrNull() }.toList()
            if (n.size >= 3 && n.take(3).all { it in 0..255 }) setColorTo(Color.rgb(n[0], n[1], n[2]), "rgb")
        }
    })
    hslEt.addTextChangedListener(watcher { s ->
        if (!busy) {
            val n = Regex("[0-9.]+").findAll(s).mapNotNull { it.value.toFloatOrNull() }.toList()
            if (n.size >= 3 && n[0] <= 360f && n[1] <= 100f && n[2] <= 100f) setColorTo(ColorMath.fromHsl(n[0], n[1] / 100f, n[2] / 100f), "hsl")
        }
    })
    val hsvListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            if (fromUser) setColorTo(Color.HSVToColor(floatArrayOf(hSb.progress.toFloat(), sSb.progress / 100f, vSb.progress / 100f)), "hsv")
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }
    hSb.setOnSeekBarChangeListener(hsvListener)
    sSb.setOnSeekBarChangeListener(hsvListener)
    vSb.setOnSeekBarChangeListener(hsvListener)
    c.addView(rowOf(
        btn("Copy HEX", false) { copyText(hex(colorValue)) },
        btn("Copy RGB", false) { copyText("rgb(${Color.red(colorValue)}, ${Color.green(colorValue)}, ${Color.blue(colorValue)})") },
        btn("Copy HSL", false) {
            val h = ColorMath.toHsl(colorValue)
            copyText("hsl(${h[0].roundToInt()}, ${(h[1] * 100).roundToInt()}%, ${(h[2] * 100).roundToInt()}%)")
        }
    ), lp(top = 10))
    content.addView(c, lp(bottom = 12))

    // palette + gradient
    val p = card()
    p.addView(label("Working palette", 17, Pal.ink, true))
    val chips = LinearLayout(this)
    chips.orientation = LinearLayout.HORIZONTAL
    val preview = GradientView(this)
    preview.radiusPx = dp(16).toFloat()
    val gvLabel = label("", 12, Pal.sub)
    var gType = GType.LINEAR
    var gAngle = 135

    fun currentSpec(): GradientSpec? =
        if (workColors.size >= 2) GradientSpec("Palette gradient", workColors.take(5), gAngle, gType) else null

    fun renderGradient() {
        val s = currentSpec()
        preview.spec = s
        gvLabel.text = if (s == null) "Add at least 2 colors to the palette to preview a gradient." else "${s.type.name.lowercase()} \u2022 ${s.colors.size} colors" + (if (s.type == GType.LINEAR) " \u2022 ${s.angle}\u00B0" else "")
    }

    fun renderChips() {
        chips.removeAllViews()
        for ((i, col) in workColors.withIndex()) {
            val v = View(this)
            v.background = rounded(col, 12)
            v.setOnClickListener { setColorTo(col, "chip") }
            v.setOnLongClickListener {
                workColors.removeAt(i)
                persistWorkPalette()
                renderChips()
                renderGradient()
                true
            }
            chips.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(8) })
        }
        if (workColors.isEmpty()) chips.addView(label("Empty. Tap \"Add current color\".", 12, Pal.sub))
    }

    val chipScroll = android.widget.HorizontalScrollView(this)
    chipScroll.isHorizontalScrollBarEnabled = false
    chipScroll.addView(chips)
    p.addView(chipScroll, lp(top = 8, bottom = 6))
    p.addView(label("Tap a color to load it, long-press to remove (max 5 used for gradients).", 11, Pal.sub))
    p.addView(rowOf(
        btn("Add current color") {
            if (workColors.size >= 12) {
                toast("Palette is full (12)")
            } else {
                workColors.add(colorValue)
                persistWorkPalette()
                renderChips()
                renderGradient()
            }
        },
        btn("Save palette", false) {
            if (workColors.isEmpty()) {
                toast("Add colors first")
            } else {
                prompt("Palette name", "My palette") { name ->
                    val arr = palettesList()
                    val o = JSONObject()
                    o.put("name", name.trim().take(40).ifEmpty { "Palette" })
                    o.put("colors", JSONArray(workColors.map { hex(it) }))
                    arr.put(o)
                    savePalettesList(arr)
                    showPage("ToolColor")
                }
            }
        }
    ), lp(top = 8))
    content.addView(p, lp(bottom = 12))

    val g = card()
    g.addView(label("Gradient generator", 17, Pal.ink, true))
    g.addView(preview, LinearLayout.LayoutParams(-1, dp(120)).apply { topMargin = dp(8) })
    g.addView(gvLabel, lp(top = 4, bottom = 6))
    g.addView(rowOf(
        btn("Linear", false) { gType = GType.LINEAR; renderGradient() },
        btn("Radial", false) { gType = GType.RADIAL; renderGradient() },
        btn("Sweep", false) { gType = GType.SWEEP; renderGradient() }
    ))
    val angle = SeekBar(this)
    angle.max = 360
    angle.progress = gAngle
    angle.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
            gAngle = pr
            renderGradient()
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    g.addView(angle, lp(top = 6))
    g.addView(rowOf(
        btn("Copy CSS", false) {
            val s = currentSpec()
            if (s == null) toast("Need 2+ colors") else copyText(DevTools.codeExports(s, "")["CSS"].orEmpty())
        },
        btn("Copy XML", false) {
            val s = currentSpec()
            if (s == null) toast("Need 2+ colors") else copyText(DevTools.codeExports(s, "")["Android XML shape"].orEmpty())
        },
        btn("To Studio", false) {
            val s = currentSpec()
            if (s == null) {
                toast("Need 2+ colors")
            } else {
                studio.load(s)
                showPage("Studio")
            }
        }
    ), lp(top = 6))
    content.addView(g, lp(bottom = 12))

    val saved = card()
    saved.addView(label("Saved palettes", 17, Pal.ink, true))
    val arr = palettesList()
    if (arr.length() == 0) {
        saved.addView(label("None yet. Build a palette above and tap Save palette.", 12, Pal.sub).apply { setPadding(0, dp(6), 0, 0) })
    }
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val cols = o.optJSONArray("colors") ?: continue
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, 0)
        row.addView(label(o.optString("name"), 14, Pal.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        val loaded = (0 until cols.length()).mapNotNull { parseHex(cols.optString(it)) }
        for (col in loaded.take(5)) {
            val v = View(this)
            v.background = rounded(col, 6)
            row.addView(v, LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(3) })
        }
        row.addView(btn("Load", false) {
            workColors.clear()
            workColors.addAll(loaded)
            persistWorkPalette()
            showPage("ToolColor")
        }, lp(-2, -2).apply { leftMargin = dp(8) })
        row.addView(btn("\u2715", false) {
            val next = JSONArray()
            for (k in 0 until arr.length()) if (k != i) next.put(arr.get(k))
            savePalettesList(next)
            showPage("ToolColor")
        }, lp(-2, -2).apply { leftMargin = dp(6) })
        saved.addView(row)
    }
    content.addView(saved, lp(bottom = 12))

    renderChips()
    renderGradient()
    setColorTo(colorValue, "init")
}
